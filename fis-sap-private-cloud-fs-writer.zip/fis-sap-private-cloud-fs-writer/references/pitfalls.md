# Bẫy đã va phải — đọc trước khi sửa hoặc sinh file FS

Toàn bộ mục này là lỗi thật đã xảy ra, không phải phòng xa.

## A. Thao tác trên file .docx bằng python-docx

**1. So khớp chuỗi tiếng Việt phải chuẩn hóa NFC.**
`p.text.strip() == 'TỔNG QUAN'` trượt dù nhìn giống hệt, vì chuỗi trong .docx ở dạng tổ hợp
còn literal trong script ở dạng dựng sẵn. Luôn so bằng
`unicodedata.normalize('NFC', x).strip()` cho cả hai vế. Chữ có dấu chồng (Ổ, Ề, Ữ) hay dính.

**2. Lấy nhầm `sectPr` làm mất header/footer từ trang 2.**
Template nhiều section. `sectPr` cấp body (phần tử cuối) thường chỉ có `headerReference
type="first"`. `sectPr` của section 1 mới có đủ `default` + `first` + `titlePg`. Khi gộp về
một section, phải giữ **cái đầu tiên** gặp trong `pPr`, không phải cái cuối. Lỗi này không lộ
ra ở trang bìa — bắt buộc render và xem trang 2.

**3. Không tự chèn `w:tblLayout`.**
`tblPr.append(OxmlElement('w:tblLayout'))` sai thứ tự schema → validate báo
`This element is not expected`. Dùng `tb.autofit = False` rồi đặt `cell.width`.

**4. Không dùng `w:updateFields` trong settings.xml** — cũng sai thứ tự schema. Để Word tự
làm mới mục lục, đặt `w:dirty="true"` lên `w:fldChar` `begin` của field TOC.

**5. Không bỏ `sectPr` ra khỏi body rồi mới `add_table`.**
`doc.add_table()` đọc `sections[-1]` để tính bề rộng → `IndexError` nếu body không còn sectPr.
python-docx tự chèn đoạn/bảng mới trước `sectPr`, nên cứ để nguyên.

**6. Chèn thêm dòng vào bìa đẩy nội dung sang trang sau.** Thêm một dòng tiêu đề thì phải bỏ
bớt 2–3 dòng trống phía dưới, nếu không dòng "Hà Nội, MM/YYYY" rơi sang trang trắng.

## B. Sửa nội dung qua script

**7. `str.replace` không khớp thì im lặng — phải assert.**
Đã có lần bảng Quản lý thay đổi bị treo ở nội dung cũ qua nhiều lượt sửa vì chuỗi đích bị ngắt
dòng khác với chuỗi trong script, mà lệnh replace không có assert nên script vẫn báo "ok".
**Luôn `assert a in s` trước mỗi `s.replace(a, b)`**, và sau khi build thì grep lại file PDF
để xác nhận nội dung mới thực sự có mặt.

**8. Xóa một mục thì phải quét tham chiếu chéo.** Bỏ mục 3.10 → còn câu "xem mục 3.10" ở 1.2,
ở bảng Tài liệu tham chiếu, ở cột Mục của bảng điểm cần xác nhận. Bỏ mục Các giả định → còn
các mã `GĐ-01`, `GĐ-05` treo trong mục 3.2, 3.6, 3.7. Sau mỗi lần xóa mục:
`grep -n "<số mục vừa bỏ>\|<mã vừa bỏ>" build.py` rồi xử lý từng chỗ — chuyển thành câu văn
đầy đủ, đừng để mã tham chiếu trỏ vào hư không.

**9. Xóa một mục có thể làm mất nội dung có giá trị nằm nhờ trong đó.** Khi bỏ mục "Nội dung
bàn giao cho TS", bảng "Yêu cầu phi chức năng" nằm cùng mục suýt mất theo. Kiểm tra nội dung
trong mục sắp xóa, cái nào còn giá trị thì chuyển sang mục khác và **nói rõ đã chuyển đi đâu**.

**10. Không tự đánh số lại mã đã dùng.** Khi bỏ một giá trị trong danh sách mã (ví dụ bỏ
`SRCRULE 04`), giữ nguyên số của các mã còn lại, đừng dồn lên — mã đã dùng mà đổi nghĩa dễ gây
hiểu nhầm giữa các bản. Với mã kiểm tra dạng V01…V08 thì đánh lại liên tục là chấp nhận được,
nhưng phải cập nhật mọi chỗ tham chiếu ("V01–V08" → "V01–V07", "V06 là kiểm tra quan trọng
nhất" → "V05"…). Nói rõ lựa chọn cho người dùng.

## C. Giao file

**11. File đang mở trong Word thì `device_commit_files` bị từ chối**, kể cả `force=true`,
với lý do `is open in another application`. Khi đó **nói ngay ở dòng đầu của câu trả lời** là
chưa ghi được và cần đóng file — đừng để lẫn vào giữa đoạn tổng kết, người dùng sẽ tưởng đã
lưu xong. Sau khi ghi, xác nhận bằng
`device_bash: ls -l --time-style=+%H:%M:%S <file>` để đối chiếu timestamp.

**12. Sửa trên đúng phiên bản người dùng đang giữ.** Người dùng có thể đã đổi tên file
(v0.2 → v0.1) hoặc giữ bản `_OldVersion`. Trước khi sửa, `ls` thư mục dự án để biết file nào
đang là bản hiện hành, và hỏi/nói rõ sẽ ghi vào file nào. Khi họ nói "cập nhật trên vX luôn"
thì **không tăng version**, gộp mô tả thay đổi vào đúng dòng vX của bảng Quản lý thay đổi.

## D. Nội dung SAP hay sai

**13. `EBAN` không có `BUKRS`.** Company code của dòng PR phải suy từ nhà máy:
`EBAN-WERKS → T001W-BWKEY → T001K-BUKRS`. Trên PO thì `EKPO-BUKRS` có thật (người dùng dự án
MAG đã xác nhận).

**14. Bảng master data có hiệu lực theo thời gian phải đọc theo ngày tham chiếu, không lấy bản
ghi mới nhất.** `CSKS` khóa `(MANDT, KOKRS, KOSTL, DATBI)`, thuộc tính `DATAB`; chọn bản ghi
thỏa `DATAB ≤ ngày tham chiếu ≤ DATBI`. Lấy bản mới nhất sẽ cho kết quả sai với chứng từ cũ.

**15. `KOKRS` là khóa bắt buộc khi đọc `CSKS`**, suy từ company code qua `TKA02`.

**16. Trên S/4HANA, cost element đã hợp nhất vào master data G/L account** — không còn bảng
`CSKB` riêng. Tên trường loại tài khoản cần đội phát triển xác nhận trên phiên bản dự án.
