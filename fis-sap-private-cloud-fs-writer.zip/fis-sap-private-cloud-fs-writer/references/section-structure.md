# Khung nội dung FS và ranh giới FS / TS

## 1. Khung 3 mục theo template MAG

Template `MAG_SAP_2026_PM_FS Temp_Form.docx` quy định đúng ba mục lớn. Giữ nguyên tên
và thứ tự các mục con có sẵn; nếu deliverable không có nội dung cho một mục thì ghi `N/A`
thay vì xóa mục — trừ khi người dùng yêu cầu bỏ.

| Mục | Nội dung |
|---|---|
| **1. TỔNG QUAN** | 1.1 Mục đích tài liệu · 1.2 Phạm vi tài liệu · 1.3 Tài liệu tham chiếu (STT / Tên tài liệu / Người tạo / Ghi chú) · 1.4 Thuật ngữ viết tắt (STT / Thuật ngữ / Định nghĩa) |
| **2. MÔ TẢ YÊU CẦU** | 2.1 Mục đích · 2.2 Quy trình nghiệp vụ liên quan · 2.3 Các giả định · 2.4 Rủi ro · 2.5 Ràng buộc · 2.6 Mô tả yêu cầu nghiệp vụ · 2.7 Format báo cáo/chứng từ · 2.8 Hình thức báo cáo/chứng từ |
| **3. MÔ TẢ THIẾT KẾ CHỨC NĂNG** | 3.1 Thông tin chung · 3.2 Các bảng dữ liệu cần phát triển · 3.3 Tham số lọc · 3.4 Các màn hình chức năng · 3.5 Nội dung chi tiết báo cáo/chứng từ |

**Mục 3 mở rộng được.** Với enhancement có logic nghiệp vụ (không chỉ là một báo cáo),
thêm các mục con sau 3.5 — đây là chỗ đặt phần "ruột" của FS:

- 3.6 Quy tắc / logic xử lý (dữ liệu đầu vào · trình tự xử lý · từng bước quy tắc ·
  quy tắc ghi giá trị · xử lý khi không tìm thấy · kiểm tra hợp lệ · thời điểm tính lại)
- 3.7 Tích hợp với hệ thống ngoài
- 3.8 Phân quyền
- 3.9 Kiểm thử (bảng test case mã T01, T02…)

### Mẫu bảng của template phải dùng lại đúng dạng

- **3.3 Tham số lọc** — 7 cột: `STT | Tham số | Mô tả | Điều kiện | Giá trị mặc định | Bắt buộc | Mô tả thêm`.
  Cột Điều kiện dùng `Single value` / `Multiple Value`.
- **3.5 Nội dung chi tiết báo cáo** — 4 cột: `Trường hiển thị | Mô tả | Nguồn dữ liệu / ghi chú | Mô tả thêm`.

## 2. Ranh giới FS / TS — quy tắc đã chốt với người dùng

FS trả lời **hệ thống phải làm gì và làm trên dữ liệu nào**. TS trả lời **hiện thực thế nào**.

### FS PHẢI có

- Yêu cầu nghiệp vụ, hiện trạng, khoảng trống so với cơ chế chuẩn của SAP.
- **Cấu trúc dữ liệu ở mức trường** cho mọi bảng và báo cáo phải xây dựng thêm:
  `Trường | Kiểu dữ liệu (kèm ĐỘ DÀI) | Khóa | Trường chuẩn tham chiếu | Diễn giải nghiệp vụ`.
  Ví dụ: `BUKRS · CHAR 4 · khóa · T001-BUKRS`, `MATKL · CHAR 9 · khóa · T023-MATKL`,
  `SAKNR · CHAR 10 · SKA1-SAKNR`.
- **Logic chỉ đích danh bảng/trường chuẩn của SAP** kèm mô tả nghiệp vụ đi cùng. Ví dụ:
  `KOSTL → CSKS (KOKRS, KOSTL, hiệu lực theo ngày tham chiếu) → CSKS-KOSAR`;
  ghi kết quả vào `EBKN-SAKTO` / `EKKN-SAKTO`; ngày tham chiếu `EBAN-BADAT` / `EKKO-BEDAT`.
- Ví dụ dữ liệu cấu hình minh họa, quy tắc kiểm tra khi khai (V01, V02…), quy tắc kiểm tra
  runtime (C01, C02…), quy tắc kiểm tra trường trên màn hình (R01, R02…).
- Hành vi màn hình, phân quyền theo nhóm người dùng, test case, điểm cần khách hàng xác nhận.

### FS KHÔNG được có

- Tên kỹ thuật của đối tượng phát triển: tên bảng Z, domain, data element, class, method,
  message class, package, BAdI implementation, search help.
- Điểm mở rộng kỹ thuật cụ thể (tên BAdI, customer exit, số màn hình, append structure).
- Mã giả, danh mục thao tác của chương trình, cấu trúc lớp.
- Chi tiết hiện thực: delivery class, bộ đệm, transport request, table maintenance generator.

Khi cần nhắc tới một trường mới chưa có tên: đặt tên gợi ý và ghi rõ *"tên kỹ thuật cuối cùng
do TS đặt theo quy ước của dự án"*.

## 3. Quy ước viết

**Ngôn ngữ.** Tiếng Việt, giữ nguyên thuật ngữ kỹ thuật tiếng Anh (Account Assignment,
Cost Center Category, chart of accounts…). Không dịch tên bảng, trường, transaction.

**Nhãn mức độ xác thực.** Với nội dung chưa kiểm chứng trên hệ thống dự án, đặt nhãn ngay
đầu câu: `[Inference]` (suy luận từ cơ chế chuẩn SAP) hoặc `[Unverified]` (giả định kỹ thuật).
Nếu tài liệu có mục Các giả định thì mỗi nhãn phải có một dòng tương ứng trong đó, kèm
**ảnh hưởng nếu giả định sai**. Nếu người dùng bỏ mục Các giả định, chuyển nội dung cảnh báo
thành câu văn đầy đủ tại chỗ, KHÔNG để lại mã tham chiếu treo.

Đặc biệt hay sai và phải đánh nhãn: tên method của khung xử lý, tên structure EXTENSIONIN,
số màn hình customer exit, sự tồn tại của một trường trên bảng chuẩn (ví dụ `EBAN` không có
`BUKRS`, phải suy qua `WERKS → T001W → T001K`).

**Giải thích vì sao.** Mọi lựa chọn không hiển nhiên — nhất là lựa chọn *trông giống thiếu sót* —
cần một đoạn nêu lý do và một câu khẳng định đó là chủ ý. Các ví dụ đã dùng và hiệu quả:

- Cố tình không cho ký tự tổng quát ở một trường khóa, để thiếu cấu hình thành lỗi nhìn thấy
  được thay vì một bút toán sai âm thầm.
- Cố tình không kiểm tra quyền ở đường chạy chính, vì người dùng thiếu quyền sẽ tạo được chứng
  từ nhưng không có giá trị, gây lỗi khó hiểu.
- Cố tình không tính lại khi người dùng sửa tay trường đích, vì nếu tính lại thì họ vĩnh viễn
  không sửa được trường đó.

**Ưu tiên nhiều tầng.** Khi một bộ khóa có nhiều chiều cho phép ký tự tổng quát, đừng đọc tất
cả rồi chọn — định nghĩa một trình tự truy cập cố định và dừng ở bước đầu tiên khớp. Nếu có
chiều "phạm vi tổ chức" (company code), đặt nó ở **vòng ngoài** chứ không ngang hàng: quy tắc
riêng của một đơn vị phải luôn thắng quy tắc dùng chung, kể cả khi quy tắc riêng tổng quát hơn
ở các chiều khác. Ghi cả số vòng lẫn số bước vào nhật ký và báo cáo tra cứu.

**Sơ đồ.** ASCII trong khối Courier New 8pt, không dùng ảnh (ảnh không sửa được ở bản sau).
Viết không dấu để các cột thẳng hàng.

**Bảng "Danh mục thành phần".** Liệt kê các thành phần phải xây dựng theo chức năng nghiệp vụ.
Người dùng MAG **không muốn cột ước lượng MD** trong bảng này — bỏ cột MD và bỏ luôn dòng
Tổng cộng cùng ghi chú về ngày công.

## 4. Bối cảnh dự án MAG (Masterise)

Hệ sinh thái Masterise gồm nhiều pháp nhân: MAG (chủ đầu tư, cung cấp dịch vụ tư vấn và tài
chính cho các đơn vị còn lại) và MAA – Masterise Agent (phân phối bất động sản). Hệ quả:

- Hệ thống tài khoản và master data gắn với từng company code → bảng cấu hình dùng chung phải
  có **BUKRS trong khóa**. Có thể cho phép `'*'` để dùng chung toàn tập đoàn, nhưng khi đó
  việc kiểm tra tài khoản khi khai chỉ làm được ở **mức chart of accounts** (`SKA1`), còn việc
  đã mở tại company code cụ thể (`SKB1`) phải để runtime kiểm tra.
- **PMS** là hệ thống nguồn tích hợp PR/PO và chứng từ khác vào SAP. Luôn xét kênh tích hợp
  như một kênh ngang hàng với nhập liệu online, đi qua **cùng một lớp logic** — không viết
  nhánh riêng, vì hai nhánh sẽ trôi xa nhau và cùng đầu vào cho hai kết quả khác nhau.
- Nền tảng **S/4HANA Private Cloud Edition**: được dùng append structure, customer exit, BAdI
  cổ điển, SM30, table maintenance generator. KHÔNG áp ràng buộc của Public Cloud vào tài liệu.
