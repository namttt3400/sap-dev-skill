# Quy ước đặt tên tài liệu và đối tượng phát triển — dự án MAG

## Tên file tài liệu

```
<MÃ_DỰ_ÁN>_<LOẠI_TÀI_LIỆU>_<PHÂN_HỆ>_<ĐỐI_TƯỢNG>_v<phiên bản>.docx
```

Mã dự án hiện tại: **`MAG_SAP_2026_PM`**. Ghép lại:

```
MAG_SAP_2026_PM_FS_<PH>_<ĐỐI_TƯỢNG>_v0.1.docx
```

Quy tắc từng thành phần:

| Thành phần | Quy tắc | Ví dụ |
|---|---|---|
| Mã dự án | Cố định `MAG_SAP_2026_PM` | |
| Loại tài liệu | `FS`, `BP`, `UM`, `TC`, `BRD` | `FS` |
| Phân hệ | Mã phân hệ SAP viết hoa | `MM`, `SD`, `FI`, `CO`, `PS`, `MD` (master data) |
| Đối tượng | Viết hoa, không dấu, gạch dưới, ngắn gọn — tên chức năng chứ không phải mô tả | `GLDET`, `BP`, `MATERIAL` |
| Phiên bản | `v0.1`, `v0.2`… chữ `v` thường, phần thân dùng `V0.1` chữ V hoa | `v0.1` |

Ví dụ thật trong dự án:

- `MAG_SAP_2026_PM_FS_MD_BP_v0.1.docx` — FS master data Business Partner
- `MAG_SAP_2026_PM_FS_MD_MAT_v0.1.docx` — FS master data Material
- `MAG_SAP_2026_PM_FS_MM_GLDET_v0.1.docx` — FS tự động xác định G/L account trên PR/PO

**Mã tài liệu** (`meta.docCode`, hiển thị ở bìa và header trang) = tên file bỏ phần `_v0.1.docx`.

## Kỷ luật phiên bản

Mỗi lần phát hành lại sau bản đầu: tăng phiên bản (V0.1 → V0.2 → …) VÀ thêm một dòng vào bảng
QUẢN LÝ THAY ĐỔI. Dòng thay đổi phải nêu mục/bảng bị ảnh hưởng và giải thích **vì sao** đổi,
không chỉ đổi cái gì. Tên file mang phiên bản mới; bản cũ để người dùng tự quyết định giữ hay xóa.

Giữ nguyên mã tài liệu qua các phiên bản — chỉ đổi phần `_v`.

**Chỉ tăng phiên bản khi người dùng yêu cầu.** Trong một đợt sửa nhiều vòng, người dùng thường
nói "cập nhật trên v0.2 luôn" — khi đó ghi đè đúng file cũ, KHÔNG tạo v0.3, và gộp mô tả thay
đổi vào chính dòng V0.2 của bảng Quản lý thay đổi (viết lại trọn dòng, đừng nối chuỗi bằng
replace vì dễ trượt — xem `pitfalls.md` mục 7).

**Trước khi sửa, `ls` thư mục dự án.** Người dùng có thể đã đổi tên file hoặc giữ bản
`*_OldVersion.docx`. Xác định file nào là bản hiện hành rồi mới thao tác, và nói rõ sẽ ghi
vào file nào.

## Quy ước đối tượng phát triển (đề xuất mặc định)

Nếu MAG chưa ban hành quy ước riêng thì dùng bộ này và ghi rõ ở mục 2.6 rằng đây là đề xuất,
kèm một điểm ĐM để MAG xác nhận.

| Loại | Quy ước | Ví dụ |
|---|---|---|
| Package | `Z<PH>_<CHỨC_NĂNG>` | `ZMM_GLDET` |
| Bảng | `ZT<PH>_<TÊN>` | `ZTMM_GLDET`, `ZTMM_VWZWK` |
| Bảng text | Tên bảng chính + `T` | `ZTMM_VWZWKT` |
| Domain | `ZDO_<TÊN>` | `ZDO_GLDET_MODE` |
| Data element | `ZDE_<TÊN>` | `ZDE_VWZWK` |
| Search help | `ZSH_<TÊN>` | `ZSH_VWZWK` |
| Class | `ZCL_<PH>_<TÊN>` | `ZCL_MM_GLDET` |
| Exception class | `ZCX_<PH>_<TÊN>` | `ZCX_MM_GLDET` |
| Message class | `Z<PH>_<TÊN>` | `ZMM_GLDET` |
| BAdI implementation | `Z<PH>_<TÊN>_<NGỮ_CẢNH>` | `ZMM_GLDET_REQ`, `ZMM_GLDET_PO` |
| Append structure | `ZA<BẢNG>_<TÊN>` | `ZAEBAN_GLDET` |
| Trường append | `ZZ<TÊN>` (bắt buộc theo quy ước SAP cho include `CI_*`) | `ZZVWZWK` |
| Chương trình | `Z<PH>_<TÊN>` | `ZMM_GLDET_SIM` |
| Authorization group | 4 ký tự, `Z<PH><số>` | `ZMM1` |

Delivery class: bảng cấu hình dùng `C` (transport được qua Customizing Request);
bảng log/dữ liệu phát sinh dùng `A`. Transport tách riêng Workbench Request (đối tượng chương trình)
và Customizing Request (dữ liệu bảng cấu hình), không gộp.
