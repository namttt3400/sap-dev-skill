# Format tài liệu FS — dự án MAG (Masterise) / SAP S/4HANA Private Cloud

## 0. Nguyên tắc số một: dựng trên file template, đừng sinh lại từ đầu

Dự án MAG có file template chính thức: **`MAG_SAP_2026_PM_FS Temp_Form.docx`** (nằm trong
thư mục dự án). File này chứa những thứ không tái tạo lại được bằng cách gõ tay:

- **Header**: bảng 3 cột không viền, có đường kẻ dưới — logo FPT (ảnh nhúng) | dòng chữ
  `TRIỂN KHAI HỆ THỐNG SAP S/4 HANA` (14pt) | logo khách hàng (ảnh nhúng).
- **Footer**: `01.20-BM/TV/HDCV/FIS v1/0` | `Confidential` | `Trang X/Y` (field PAGE/NUMPAGES).
- **Style**: Heading 2 / Heading 3 gắn numbering tự động (1., 1.1., 2., 2.1.…). Chỉ cần
  áp style, KHÔNG tự gõ số mục — gõ tay sẽ sai ngay khi thêm/bớt một mục.
- **Trang ký**: hai bảng ĐẠI DIỆN FPT và ĐẠI DIỆN \<khách hàng\>, mỗi bảng có
  Vai trò | Tên và chức vụ | Chữ ký | Ghi chú.
- **Mục lục**: field TOC.

Quy trình: mở template bằng python-docx → điền bìa → **cắt phần thân mẫu** → viết nội dung mới
→ lưu ra tên file mới. Script sẵn sàng dùng: `scripts/fs_from_template.py`.

Chỉ khi dự án KHÔNG có template thì mới sinh từ đầu bằng `scripts/fs_lib.js` +
`scripts/build_fs_template.js` (đặc tả ở mục 5 bên dưới).

## 1. Thông số của template MAG

| Hạng mục | Giá trị |
|---|---|
| Khổ giấy | A4 dọc, 11909 × 16834 dxa |
| Lề | trái 1701, phải/trên/dưới 1134 dxa |
| **Bề rộng nội dung** | **9074 dxa** — tổng bề rộng cột của MỌI bảng phải bằng đúng số này |
| Font | Times New Roman toàn bộ |
| Normal | 24 half-points = **12 pt** |
| Header (chữ giữa) | 28 = 14 pt |
| Tiêu đề bìa dòng 1 | 15–16 pt in đậm (có sẵn trong template) |
| Nền header bảng nội dung | `1F4E79`, chữ trắng đậm |
| Nền banner bìa / header bảng bìa | `244061` |
| Nền cột nhãn bảng Thông tin tài liệu | `BFBFBF` |
| Khối mã / sơ đồ ASCII | Courier New 8 pt |

> Cỡ chữ 12 pt là của template. Người dùng có một quy ước riêng "Times New Roman size 10" —
> khi họ chỉ định làm theo template thì template thắng. Hỏi lại nếu không rõ.

## 2. Quy tắc bảng

- Header: nền `1F4E79`, chữ trắng đậm, căn trái. Đánh dấu `w:tblHeader` để lặp qua trang.
- Ô dữ liệu căn trái; các cột mã/số ngắn ở đầu bảng căn giữa (`center_cols`).
- Caption đặt **trên** bảng, in nghiêng, `Bảng N. <mô tả>`, N đánh số liên tục toàn tài liệu.
- Sơ đồ đánh số riêng: `Sơ đồ N. <mô tả>`.
- Tổng bề rộng cột = 9074. Hàm `tbl()` trong script có assert kiểm tra.

### Bề rộng tối thiểu ở 12 pt (đã va phải thực tế)

| Nội dung header | Tối thiểu | Ghi chú |
|---|---|---|
| `Mã` | 700 | |
| `Khóa` | **900** | 750 bị xuống dòng thành "Khó / a" |
| `Kênh`, `Bước` | **900** | |
| `V02b`, `BUKRS`, `KNTTP` | **880** | |
| `Cho phép '*'` | **1000** | |

Bảng từ 7 cột trở lên: đặt `size=9` cho cả bảng thay vì bóp cột đến mức vỡ chữ.

## 3. Bìa và các trang đầu

Thứ tự do template quy định, chỉ điền dữ liệu:

1. Tiêu đề `TÀI LIỆU THIẾT KẾ FS` → chèn thêm ngay dưới một dòng tên chức năng (16 pt đậm,
   căn giữa). Chèn thêm dòng sẽ đẩy dòng `Hà Nội, MM/YYYY` sang trang sau → script bỏ bớt
   2–3 dòng trống sau bảng Thông tin tài liệu để bù.
2. Bảng **Thông tin tài liệu**: Mã dự án · Mã tài liệu · Phân hệ · Người lập · Phiên bản ·
   Ngày cập nhật.
3. `Hà Nội, MM/YYYY`.
4. Bảng **QUẢN LÝ THAY ĐỔI**: Ngày thay đổi | Mục, bảng, sơ đồ được thay đổi | Mô tả thay đổi |
   Phiên bản. **Không có cột T/S/X** — đó là của template khác, đừng thêm vào.
5. Hai bảng **trang ký**. Đổi tên khách hàng; **xóa trắng tên người** của dự án mẫu trong
   template (đó là nhân sự dự án khác) và nói với người dùng để họ điền.
6. **Mục lục** (field TOC).

## 4. Kiểm tra bắt buộc trước khi giao

```bash
python3 build.py

# 1) cấu trúc docx
python3 /mnt/skills/public/docx/scripts/office/validate.py <file>.docx

# 2) render PDF và SOI MẮT: bìa, trang ký, một bảng nhiều cột, một bảng dài tràn trang
python3 /mnt/skills/public/docx/scripts/office/soffice.py --headless --convert-to pdf <file>.docx
pdftoppm -jpeg -r 70 -f <trang> -l <trang> <file>.pdf p

# 3) soát tồn dư sau khi xóa nội dung: grep các từ khóa vừa bỏ trong text trích ra
pdftotext <file>.pdf t.txt && grep -n "<từ khóa vừa bỏ>" t.txt
```

Bắt buộc xem trang 2 trở đi để chắc header/footer còn nguyên — lỗi lấy nhầm `sectPr`
làm mất header từ trang 2 và không lộ ra ở trang bìa.

Xóa file PDF/JPG/txt tạm trước khi giao.

## 5. Phương án dự phòng: sinh từ đầu (dự án không có template)

`scripts/fs_lib.js` (Node + thư viện `docx`) dựng bìa banner navy `244061`, header/footer
không viền, bảng header navy chữ trắng, bảng Quản lý thay đổi 5 cột (có T/S/X), mục lục.
Bề rộng nội dung 9922 dxa, body 10 pt. Dùng `scripts/build_fs_template.js` làm khung.

```bash
NODE_PATH=/usr/local/lib/node_modules_global node build.js
```

Đây là phương án dự phòng. Có template thì luôn dùng template.
