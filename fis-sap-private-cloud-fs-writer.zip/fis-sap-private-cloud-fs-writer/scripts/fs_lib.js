// Generator for two FS documents: ZC_Product_Characteristic & ZC_Batch_Characteristic
// Format adapted from CASLA_SAPER_2025_PM_FS template (Times New Roman, A4 portrait, VN content)

const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, PageOrientation, LevelFormat,
  HeadingLevel, BorderStyle, WidthType, ShadingType, VerticalAlign,
  PageNumber, PageBreak, TableOfContents, TabStopType, TabStopPosition,
} = require("docx");

// ===== Style constants =====
const FONT = "Times New Roman";
const SZ_BODY = 20;     // 10pt
const SZ_TITLE = 30;    // 15pt
const SZ_H1 = 26;       // 13pt
const SZ_H2 = 24;       // 12pt
const SZ_H3 = 22;       // 11pt
const COLOR_HEADER = "244061";   // navy header (chuan tai lieu MAG)
const COLOR_TITLE_BG = "1F3864"; // dark blue
const PAGE_WIDTH = 11906;        // A4 in DXA
const PAGE_HEIGHT = 16838;
const MARGIN_LEFT = 1134;        // ~2cm
const MARGIN_OTHER = 850;        // ~1.5cm
const CONTENT_WIDTH = PAGE_WIDTH - MARGIN_LEFT - MARGIN_OTHER; // ~9922

// ===== Helpers =====
const border = { style: BorderStyle.SINGLE, size: 6, color: "000000" };
const borders = { top: border, bottom: border, left: border, right: border };
const noBorder = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };

function txt(text, opts = {}) {
  return new TextRun({
    text: String(text ?? ""),
    font: FONT,
    size: opts.size || SZ_BODY,
    bold: opts.bold || false,
    italics: opts.italics || false,
    color: opts.color || "000000",
    break: opts.break || 0,
  });
}

function p(text, opts = {}) {
  const children = Array.isArray(text)
    ? text.map((t) => (typeof t === "string" ? txt(t, opts) : t))
    : [typeof text === "string" ? txt(text, opts) : text];
  return new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    spacing: opts.spacing || { before: 60, after: 60, line: 300 },
    indent: opts.indent,
    children,
    pageBreakBefore: opts.pageBreakBefore || false,
  });
}

function heading(text, level, opts = {}) {
  const sizeMap = { 1: SZ_H1, 2: SZ_H2, 3: SZ_H3 };
  const headingMap = {
    1: HeadingLevel.HEADING_1,
    2: HeadingLevel.HEADING_2,
    3: HeadingLevel.HEADING_3,
  };
  return new Paragraph({
    heading: headingMap[level],
    spacing: { before: 240, after: 120 },
    pageBreakBefore: opts.pageBreakBefore || false,
    children: [
      new TextRun({
        text,
        font: FONT,
        size: sizeMap[level],
        bold: true,
        color: "000000",
      }),
    ],
  });
}

function blankLine() {
  return new Paragraph({ children: [txt("")] });
}

function cell(content, opts = {}) {
  const widthDxa = opts.width;
  const fill = opts.fill || null;
  const align = opts.align || AlignmentType.LEFT;
  const verticalAlign = opts.verticalAlign || VerticalAlign.CENTER;
  const bold = opts.bold || false;
  const color = opts.color || "000000";

  let paragraphs;
  if (Array.isArray(content)) {
    paragraphs = content.map((c) =>
      typeof c === "string"
        ? new Paragraph({
            alignment: align,
            spacing: { before: 40, after: 40, line: 280 },
            children: [txt(c, { bold, color })],
          })
        : c
    );
  } else if (typeof content === "string") {
    paragraphs = [
      new Paragraph({
        alignment: align,
        spacing: { before: 40, after: 40, line: 280 },
        children: [txt(content, { bold, color })],
      }),
    ];
  } else {
    paragraphs = [content];
  }

  const cellOpts = {
    borders: opts.noBorders ? noBorders : borders,
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    verticalAlign,
    children: paragraphs,
  };
  if (widthDxa) cellOpts.width = { size: widthDxa, type: WidthType.DXA };
  if (fill) cellOpts.shading = { fill, type: ShadingType.CLEAR };

  return new TableCell(cellOpts);
}

function buildTable(rows, columnWidths, opts = {}) {
  const totalWidth = columnWidths.reduce((a, b) => a + b, 0);
  return new Table({
    width: { size: totalWidth, type: WidthType.DXA },
    columnWidths,
    rows: rows.map(
      (r) =>
        new TableRow({
          tableHeader: r.header || false,
          cantSplit: true,
          children: r.cells.map((c, i) =>
            cell(c.content, {
              width: columnWidths[i],
              fill: r.header ? COLOR_HEADER : c.fill || null,
              align: c.align || AlignmentType.LEFT,
              bold: r.header || c.bold || false,
              color: r.header ? "FFFFFF" : "000000",
              verticalAlign: c.verticalAlign || VerticalAlign.CENTER,
              noBorders: opts.noBorders || false,
            })
          ),
        })
    ),
  });
}

// ===== Cover page =====
function buildCoverPage(meta) {
  // Project header table (top)
  const projectHeader = buildTable(
    [
      {
        cells: [
          { content: "" },
          {
            content: meta.projectSubtitle,
            align: AlignmentType.CENTER,
            bold: true,
          },
          { content: "" },
        ],
      },
    ],
    [2480, 4962, 2480]
  );

  const versionHeader = buildTable(
    [
      {
        cells: [
          { content: "Tài liệu thiết kế FS", bold: true },
          { content: meta.version, align: AlignmentType.CENTER, bold: true },
        ],
      },
    ],
    [7440, 2482]
  );

  // Document info table
  const docInfo = buildTable(
    [
      {
        header: true,
        cells: [
          { content: "Thông tin tài liệu", align: AlignmentType.CENTER },
          { content: "" },
        ],
      },
      { cells: [{ content: "Mã dự án" }, { content: meta.projectCode }] },
      { cells: [{ content: "Mã tài liệu" }, { content: meta.docCode }] },
      { cells: [{ content: "Phân hệ" }, { content: meta.module }] },
      { cells: [{ content: "Phiên bản" }, { content: meta.version }] },
      { cells: [{ content: "Người lập" }, { content: meta.author }] },
      { cells: [{ content: "Ngày cập nhật" }, { content: meta.updateDate }] },
    ],
    [3000, 6922]
  );

  // Use a single-row 2-cell trick to span the doc-info header across full width:
  const docInfoFixed = new Table({
    width: { size: 9922, type: WidthType.DXA },
    columnWidths: [3000, 6922],
    rows: [
      new TableRow({
        children: [
          cell("Thông tin tài liệu", {
            width: 9922,
            fill: COLOR_HEADER,
            align: AlignmentType.CENTER,
            bold: true,
          }),
        ],
      }),
      ...[
        ["Mã dự án", meta.projectCode],
        ["Mã tài liệu", meta.docCode],
        ["Phân hệ", meta.module],
        ["Phiên bản", meta.version],
        ["Người lập", meta.author],
        ["Ngày cập nhật", meta.updateDate],
      ].map(
        ([k, v]) =>
          new TableRow({
            children: [
              cell(k, { width: 3000, bold: true, fill: "BFBFBF" }),
              cell(v, { width: 6922 }),
            ],
          })
      ),
    ],
  });

  return [
    projectHeader,
    blankLine(),
    versionHeader,
    blankLine(),
    blankLine(),
    blankLine(),
    blankLine(),
    p("TÀI LIỆU THIẾT KẾ FS", {
      align: AlignmentType.CENTER,
      size: SZ_TITLE,
      bold: true,
    }),
    p("(Functional Specification Document)", {
      align: AlignmentType.CENTER,
      italics: true,
      size: SZ_H3,
    }),
    blankLine(),
    blankLine(),
    p(`Đối tượng: ${meta.objectName}`, {
      align: AlignmentType.CENTER,
      bold: true,
      size: SZ_H2,
    }),
    p(`(${meta.objectType})`, {
      align: AlignmentType.CENTER,
      italics: true,
      size: SZ_H3,
    }),
    blankLine(),
    blankLine(),
    docInfoFixed,
    blankLine(),
    blankLine(),
    blankLine(),
    blankLine(),
    p(`Hà Nội, ${meta.coverDateText}`, {
      align: AlignmentType.CENTER,
      bold: true,
      italics: true,
    }),
  ];
}

// ===== Change management page =====
function buildChangeMgmt(history) {
  const headerRow = {
    header: true,
    cells: [
      { content: "Ngày thay đổi", align: AlignmentType.CENTER },
      { content: "Mục, bảng, sơ đồ được thay đổi", align: AlignmentType.CENTER },
      { content: "Mô tả thay đổi", align: AlignmentType.CENTER },
      { content: "T/S/X", align: AlignmentType.CENTER },
      { content: "Phiên bản", align: AlignmentType.CENTER },
    ],
  };
  const rows = [headerRow, ...history.map((h) => ({
    cells: [
      { content: h.date, align: AlignmentType.CENTER },
      { content: h.section },
      { content: h.description },
      { content: h.type, align: AlignmentType.CENTER },
      { content: h.version, align: AlignmentType.CENTER },
    ],
  }))];
  return buildTable(rows, [1600, 2400, 3200, 1000, 1722]);
}

// ===== TOC =====
function buildTOC() {
  return new TableOfContents("Mục lục", {
    hyperlink: true,
    headingStyleRange: "1-3",
    stylesWithLevels: [],
  });
}

// ===== Document content sections =====

// Returns: array of doc children
function buildContent(content) {
  const out = [];

  // ---------- Section 1 ----------
  out.push(
    new Paragraph({
      pageBreakBefore: true,
      heading: HeadingLevel.HEADING_1,
      children: [
        new TextRun({ text: "1. TỔNG QUAN", font: FONT, size: SZ_H1, bold: true }),
      ],
      spacing: { before: 240, after: 120 },
    })
  );

  out.push(heading("1.1 Phạm vi tài liệu", 2));
  out.push(
    p(
      `Tài liệu này mô tả chi tiết thiết kế custom CDS view "${content.objectName}" được FPT IS phát triển trên hệ thống SAP S/4HANA Cloud Public Edition. Tài liệu này được xây dựng và xem xét bởi đội nghiệp vụ của FPT IS và CASLA cùng những người sử dụng đại diện liên quan.`
    )
  );
  out.push(p("Tài liệu này cũng là tài liệu thiết kế dành cho đội lập trình của FPT IS."));

  out.push(heading("1.2 Thuật ngữ", 2));
  out.push(p("Bảng 1. Danh mục thuật ngữ sử dụng trong tài liệu", { italics: true }));
  out.push(
    buildTable(
      [
        {
          header: true,
          cells: [
            { content: "STT", align: AlignmentType.CENTER },
            { content: "Thuật ngữ", align: AlignmentType.CENTER },
            { content: "Định nghĩa", align: AlignmentType.CENTER },
          ],
        },
        ...content.glossary.map((g, i) => ({
          cells: [
            { content: String(i + 1), align: AlignmentType.CENTER },
            { content: g.term, bold: true },
            { content: g.def },
          ],
        })),
      ],
      [800, 2400, 6722]
    )
  );

  // ---------- Section 2 ----------
  out.push(
    new Paragraph({
      pageBreakBefore: true,
      heading: HeadingLevel.HEADING_1,
      children: [
        new TextRun({ text: "2. THIẾT KẾ CHI TIẾT", font: FONT, size: SZ_H1, bold: true }),
      ],
      spacing: { before: 240, after: 120 },
    })
  );

  out.push(heading("2.1 Mô tả chung", 2));
  out.push(heading("2.1.1 Mục đích", 3));
  content.purpose.forEach((para) => out.push(p(para)));

  out.push(heading("2.1.2 Các quy định chung", 3));
  out.push(p("Bảng 2. Danh mục quy định chung", { italics: true }));
  out.push(
    buildTable(
      [
        {
          header: true,
          cells: [
            { content: "STT", align: AlignmentType.CENTER },
            { content: "Hạng mục", align: AlignmentType.CENTER },
            { content: "Quy định", align: AlignmentType.CENTER },
          ],
        },
        ...content.generalRules.map((g, i) => ({
          cells: [
            { content: String(i + 1), align: AlignmentType.CENTER },
            { content: g.item, bold: true },
            { content: g.value },
          ],
        })),
      ],
      [800, 3200, 5922]
    )
  );

  // 2.2
  out.push(heading("2.2 Thiết kế chi tiết", 2));

  // 2.2.1 Source views
  out.push(heading("2.2.1 Cấu trúc dữ liệu nguồn", 3));
  out.push(
    p(
      `Custom CDS view ${content.viewName} được xây dựng dựa trên các CDS view chuẩn của SAP S/4HANA Cloud Public Edition đã được released:`
    )
  );
  out.push(p("Bảng 3. Danh sách CDS view nguồn", { italics: true }));
  out.push(
    buildTable(
      [
        {
          header: true,
          cells: [
            { content: "STT", align: AlignmentType.CENTER },
            { content: "Tên CDS view", align: AlignmentType.CENTER },
            { content: "Vai trò", align: AlignmentType.CENTER },
            { content: "Điều kiện join / Filter", align: AlignmentType.CENTER },
          ],
        },
        ...content.sources.map((s, i) => ({
          cells: [
            { content: String(i + 1), align: AlignmentType.CENTER },
            { content: s.view, bold: true },
            { content: s.role },
            { content: s.condition },
          ],
        })),
      ],
      [700, 3200, 2400, 3622]
    )
  );

  // 2.2.2 Parameters
  out.push(heading("2.2.2 Tham số đầu vào của CDS view", 3));
  out.push(p("Bảng 4. Mô tả các tham số đầu vào", { italics: true }));
  out.push(
    buildTable(
      [
        {
          header: true,
          cells: [
            { content: "STT", align: AlignmentType.CENTER },
            { content: "Tham số", align: AlignmentType.CENTER },
            { content: "Mô tả", align: AlignmentType.CENTER },
            { content: "Giá trị mặc định", align: AlignmentType.CENTER },
            { content: "Bắt buộc", align: AlignmentType.CENTER },
          ],
        },
        ...content.parameters.map((par, i) => ({
          cells: [
            { content: String(i + 1), align: AlignmentType.CENTER },
            { content: par.name, bold: true },
            { content: par.description },
            { content: par.default, align: AlignmentType.CENTER },
            { content: par.mandatory, align: AlignmentType.CENTER },
          ],
        })),
      ],
      [600, 2200, 4222, 1900, 1000]
    )
  );

  // 2.2.3 Filter / processing logic
  out.push(heading("2.2.3 Logic xử lý / Điều kiện lọc", 3));
  content.processingLogic.forEach((para) => {
    if (typeof para === "string") {
      out.push(p(para));
    } else {
      out.push(para);
    }
  });

  // 2.2.4 Output fields
  out.push(heading("2.2.4 Mô tả các trường dữ liệu đầu ra", 3));
  out.push(
    p(
      `Bảng 5. Mô tả chi tiết các trường output của ${content.viewName}`,
      { italics: true }
    )
  );
  out.push(
    buildTable(
      [
        {
          header: true,
          cells: [
            { content: "STT", align: AlignmentType.CENTER },
            { content: "Tên trường output", align: AlignmentType.CENTER },
            { content: "Nguồn (CDS view.Field)", align: AlignmentType.CENTER },
            { content: "Mô tả", align: AlignmentType.CENTER },
            { content: "Key", align: AlignmentType.CENTER },
          ],
        },
        ...content.outputFields.map((f, i) => ({
          cells: [
            { content: String(i + 1), align: AlignmentType.CENTER },
            { content: f.name, bold: true },
            { content: f.source },
            { content: f.description },
            { content: f.key ? "X" : "", align: AlignmentType.CENTER },
          ],
        })),
      ],
      [600, 2400, 2900, 3322, 700]
    )
  );

  // 2.2.5 Sort / Key
  out.push(heading("2.2.5 Trường khóa và tiêu chí sắp xếp", 3));
  out.push(
    p(
      `Custom CDS view không tự sắp xếp dữ liệu — việc sắp xếp được consumer thực hiện. Các trường key của ${content.viewName} được liệt kê dưới đây làm tiêu chí phân biệt bản ghi duy nhất:`
    )
  );
  out.push(p("Bảng 6. Danh sách trường khóa", { italics: true }));
  out.push(
    buildTable(
      [
        {
          header: true,
          cells: [
            { content: "STT", align: AlignmentType.CENTER },
            { content: "Trường khóa", align: AlignmentType.CENTER },
            { content: "Mô tả", align: AlignmentType.CENTER },
          ],
        },
        ...content.keyFields.map((k, i) => ({
          cells: [
            { content: String(i + 1), align: AlignmentType.CENTER },
            { content: k.name, bold: true },
            { content: k.description },
          ],
        })),
      ],
      [800, 3000, 6122]
    )
  );

  // 2.2.6 Authorization
  out.push(heading("2.2.6 Mô tả các yêu cầu phân quyền dữ liệu", 3));
  content.authorization.forEach((para) => out.push(p(para)));

  // ---------- Section 3 ----------
  out.push(
    new Paragraph({
      pageBreakBefore: true,
      heading: HeadingLevel.HEADING_1,
      children: [
        new TextRun({
          text: "3. CÁC TÀI LIỆU THAM KHẢO",
          font: FONT,
          size: SZ_H1,
          bold: true,
        }),
      ],
      spacing: { before: 240, after: 120 },
    })
  );
  out.push(p("Bảng 7. Danh mục tài liệu tham khảo", { italics: true }));
  out.push(
    buildTable(
      [
        {
          header: true,
          cells: [
            { content: "STT", align: AlignmentType.CENTER },
            { content: "Tên tài liệu", align: AlignmentType.CENTER },
            { content: "Phiên bản", align: AlignmentType.CENTER },
            { content: "Mô tả", align: AlignmentType.CENTER },
          ],
        },
        ...content.references.map((r, i) => ({
          cells: [
            { content: String(i + 1), align: AlignmentType.CENTER },
            { content: r.name, bold: true },
            { content: r.version, align: AlignmentType.CENTER },
            { content: r.note },
          ],
        })),
      ],
      [600, 4000, 1500, 3822]
    )
  );

  return out;
}

// ===== Page footer =====
function buildFooter(meta) {
  return new Footer({
    children: [
      buildTable(
        [
          {
            cells: [
              { content: meta.footerLeft || meta.projectCode, align: AlignmentType.LEFT, bold: true },
              { content: "Confidential", align: AlignmentType.CENTER },
              {
                content: new Paragraph({
                  alignment: AlignmentType.RIGHT,
                  children: [
                    txt("Trang "),
                    new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: SZ_BODY }),
                    txt("/"),
                    new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FONT, size: SZ_BODY }),
                  ],
                }),
                align: AlignmentType.RIGHT,
              },
            ],
          },
        ],
        [3300, 3300, 3322],
        { noBorders: true }
      ),
    ],
  });
}

// ===== Page header =====
function buildHeader(meta) {
  return new Header({
    children: [
      buildTable(
        [
          {
            cells: [
              { content: meta.projectName, align: AlignmentType.LEFT, bold: true },
              { content: meta.version, align: AlignmentType.RIGHT },
            ],
          },
        ],
        [7422, 2500],
        { noBorders: true }
      ),
    ],
  });
}

// ===== Build full document =====
function buildDoc(meta, history, content) {
  const docChildren = [
    ...buildCoverPage(meta),
    new Paragraph({ pageBreakBefore: true, children: [txt("")] }),
    heading("QUẢN LÝ THAY ĐỔI", 1),
    buildChangeMgmt(history),
    new Paragraph({ pageBreakBefore: true, children: [txt("")] }),
    heading("MỤC LỤC", 1),
    new TableOfContents("Mục lục", {
      hyperlink: true,
      headingStyleRange: "1-3",
    }),
    ...buildContent(content),
  ];

  return new Document({
    creator: meta.author,
    title: meta.docTitle,
    description: "FS Document for " + meta.objectName,
    styles: {
      default: {
        document: { run: { font: FONT, size: SZ_BODY } },
      },
      paragraphStyles: [
        {
          id: "Heading1",
          name: "Heading 1",
          basedOn: "Normal",
          next: "Normal",
          quickFormat: true,
          run: { size: SZ_H1, bold: true, font: FONT },
          paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 0 },
        },
        {
          id: "Heading2",
          name: "Heading 2",
          basedOn: "Normal",
          next: "Normal",
          quickFormat: true,
          run: { size: SZ_H2, bold: true, font: FONT },
          paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 1 },
        },
        {
          id: "Heading3",
          name: "Heading 3",
          basedOn: "Normal",
          next: "Normal",
          quickFormat: true,
          run: { size: SZ_H3, bold: true, italics: true, font: FONT },
          paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 2 },
        },
      ],
    },
    features: { updateFields: true },
    sections: [
      {
        properties: {
          page: {
            size: { width: PAGE_WIDTH, height: PAGE_HEIGHT },
            margin: {
              top: MARGIN_OTHER,
              right: MARGIN_OTHER,
              bottom: MARGIN_OTHER,
              left: MARGIN_LEFT,
            },
          },
        },
        headers: { default: buildHeader(meta) },
        footers: { default: buildFooter(meta) },
        children: docChildren,
      },
    ],
  });
}


// ===== Trang bia chuan MAG (banner navy) =====
function buildCoverMAG(meta) {
  const CW = PAGE_WIDTH - MARGIN_LEFT - MARGIN_OTHER;
  const banner = new Table({
    width: { size: CW, type: WidthType.DXA },
    columnWidths: [CW],
    rows: [
      new TableRow({
        cantSplit: true,
        children: [
          cell(
            meta.coverLines.map((l) =>
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 120, after: 120, line: 300 },
                children: [new TextRun({ text: l.text, font: FONT, size: l.size, bold: true, color: "FFFFFF" })],
              })
            ),
            { width: CW, fill: COLOR_HEADER, align: AlignmentType.CENTER }
          ),
        ],
      }),
    ],
  });

  const docInfo = buildTable(
    [
      { header: true, cells: [{ content: "Thông tin tài liệu" }, { content: "" }] },
      { cells: [{ content: "Mã dự án", bold: true, fill: "BFBFBF" }, { content: meta.projectCode }] },
      { cells: [{ content: "Mã tài liệu", bold: true, fill: "BFBFBF" }, { content: meta.docCode }] },
      { cells: [{ content: "Phân hệ", bold: true, fill: "BFBFBF" }, { content: meta.module }] },
      { cells: [{ content: "Người tạo", bold: true, fill: "BFBFBF" }, { content: meta.author }] },
      { cells: [{ content: "Phiên bản", bold: true, fill: "BFBFBF" }, { content: meta.version }] },
      { cells: [{ content: "Ngày cập nhật", bold: true, fill: "BFBFBF" }, { content: meta.updateDate }] },
    ],
    [3200, CW - 3200]
  );

  return [
    blankLine(), blankLine(),
    banner,
    blankLine(), blankLine(),
    docInfo,
    blankLine(), blankLine(),
    p(`Hà Nội, ${meta.coverDateText}`, { align: AlignmentType.CENTER, bold: true, italics: true }),
  ];
}

// ===== Rap toan bo tai lieu =====
function buildFsDoc(meta, history, bodyChildren) {
  return new Document({
    creator: meta.author,
    title: meta.docTitle,
    description: meta.docTitle,
    styles: {
      default: { document: { run: { font: FONT, size: SZ_BODY } } },
      paragraphStyles: [
        { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: SZ_H1, bold: true, font: FONT },
          paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 0 } },
        { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: SZ_H2, bold: true, font: FONT },
          paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 1 } },
        { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: SZ_H3, bold: true, italics: true, font: FONT },
          paragraph: { spacing: { before: 160, after: 80 }, outlineLevel: 2 } },
      ],
    },
    features: { updateFields: true },
    sections: [
      {
        properties: {
          page: {
            size: { width: PAGE_WIDTH, height: PAGE_HEIGHT },
            margin: { top: MARGIN_OTHER, right: MARGIN_OTHER, bottom: MARGIN_OTHER, left: MARGIN_LEFT },
          },
        },
        headers: { default: buildHeader(meta) },
        footers: { default: buildFooter(meta) },
        children: [
          ...buildCoverMAG(meta),
          new Paragraph({ pageBreakBefore: true, children: [txt("")] }),
          heading("QUẢN LÝ THAY ĐỔI", 1),
          buildChangeMgmt(history),
          new Paragraph({ pageBreakBefore: true, children: [txt("")] }),
          heading("MỤC LỤC", 1),
          new TableOfContents("Mục lục", { hyperlink: true, headingStyleRange: "1-3" }),
          ...bodyChildren,
        ],
      },
    ],
  });
}

module.exports = {
  buildCoverMAG,
  buildFsDoc,
  Packer,
  buildDoc,
  // Helpers for reuse in other FS builders
  txt, p, heading, blankLine, cell, buildTable,
  buildCoverPage, buildChangeMgmt, buildHeader, buildFooter,
  FONT, SZ_BODY, SZ_TITLE, SZ_H1, SZ_H2, SZ_H3,
  COLOR_HEADER, PAGE_WIDTH, PAGE_HEIGHT, MARGIN_LEFT, MARGIN_OTHER, CONTENT_WIDTH,
};
