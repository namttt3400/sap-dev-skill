# -*- coding: utf-8 -*-
"""
Dựng tài liệu FS TRÊN CHÍNH file template .docx của dự án.

Vì sao phải làm theo cách này thay vì sinh file từ đầu: template của dự án chứa
header có logo (ảnh nhúng), footer có mã biểu mẫu, bộ style có đánh số tự động cho
Heading, và các trang ký. Sinh lại từ đầu là chép tay những thứ đó và luôn lệch.
Mở template rồi thay phần thân giữ được 100% các phần trên.

CÁCH DÙNG
    1. cp file template về thư mục làm việc, đặt tên tpl.docx
    2. cp script này thành build.py, sửa phần CẤU HÌNH + hàm build()
    3. python3 build.py
    4. validate + render PDF soi mắt (xem SKILL.md mục "Kiểm tra")

CẤU HÌNH bên dưới đang đặt theo template MAG (MAG_SAP_2026_PM_FS Temp_Form.docx).
Với template khác: mở template ra, liệt kê body children để xác định lại
COVER_TITLE / FIRST_HEADING / chỉ số các bảng bìa (xem SKILL.md).
"""
import copy
import unicodedata

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph

# ===================== CẤU HÌNH =====================
TPL = 'tpl.docx'
OUT = 'MAG_SAP_2026_PM_FS_<PH>_<DOI_TUONG>_v0.1.docx'

CW = 9074              # bề rộng nội dung = pgSz - lề trái - lề phải (template MAG: 11909-1701-1134)
HDR_FILL = '1F4E79'    # màu nền header bảng nội dung của template MAG
LABEL_FILL = 'BFBFBF'  # màu nền cột nhãn (bảng Thông tin tài liệu)

COVER_TITLE = 'TÀI LIỆU THIẾT KẾ FS'   # dòng tiêu đề có sẵn trên bìa template
FIRST_HEADING = 'TỔNG QUAN'            # heading đầu tiên của phần thân mẫu -> cắt từ đây
CITY_PREFIX = 'Hà Nội,'

DOC_TITLE_LINES = '<TÊN CHỨC NĂNG VIẾT HOA>\n(<PHẠM VI BỔ SUNG>)'
CITY_LINE = 'Hà Nội, 08/2026'
CUSTOMER = 'MAG'                        # thay chuỗi tên khách hàng trên trang ký

INFO = {                                # bảng "Thông tin tài liệu" trên bìa
    'Mã dự án': 'MAG_SAP_2026_PM',
    'Mã tài liệu': 'MAG_SAP_2026_PM_FS_<PH>_<DOI_TUONG>',
    'Phân hệ': '<PH> – <Tên phân hệ>',
    'Người lập': 'Đội dự án FPT',
    'Phiên bản': 'V0.1',
    'Ngày cập nhật': '<DD.MM.YYYY>',
}

CHANGE_LOG = [                          # Ngày | Mục/bảng/sơ đồ | Mô tả thay đổi | Phiên bản
    ('<DD.MM.YYYY>', 'Toàn bộ tài liệu', 'Tạo mới tài liệu thiết kế FS cho chức năng <...>', 'V0.1'),
]

# ===================== TIỆN ÍCH =====================
def _n(t):
    """Chuẩn hóa NFC. BẮT BUỘC khi so khớp tiếng Việt lấy từ .docx: chuỗi trong file
    có thể ở dạng tổ hợp (NFD) còn literal trong script ở dạng dựng sẵn (NFC),
    so sánh trực tiếp sẽ trượt dù nhìn giống hệt nhau."""
    return unicodedata.normalize('NFC', t or '').strip()


doc = Document(TPL)
body = doc.element.body
_bang = [0]


def shade(cell, hexfill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear'); shd.set(qn('w:color'), 'auto'); shd.set(qn('w:fill'), hexfill)
    tcPr.append(shd)


def set_cell(cell, text, bold=False, white=False, center=False, size=None):
    cell.text = ''
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(str(text))
    r.bold = bold
    if white:
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
    if size:
        r.font.size = Pt(size)


def widths(tb, cols):
    """Đặt bề rộng cột. KHÔNG chèn w:tblLayout bằng tay — sai thứ tự schema, file lỗi."""
    tb.autofit = False
    for row in tb.rows:
        for i, c in enumerate(row.cells):
            c.width = int(cols[i] * 635)
    for i, c in enumerate(tb.columns):
        c.width = int(cols[i] * 635)


def add_p(text, bullet=False):
    p = doc.add_paragraph(style='List Paragraph' if bullet else 'Normal')
    if bullet:
        p.paragraph_format.left_indent = Pt(18)
        p.add_run('–  ' + text)
    else:
        p.add_run(text)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(6)
    return p


def add_ps(items, bullet=False):
    for t in items:
        add_p(t, bullet=bullet)


def h2(text):
    return doc.add_paragraph(text, style='Heading 2')   # tự đánh số 1. 2. 3.


def h3(text):
    return doc.add_paragraph(text, style='Heading 3')   # tự đánh số x.1 x.2


def tbl(caption, headers, rows, cols, center_cols=0, size=None):
    """cols: list bề rộng dxa, TỔNG PHẢI BẰNG CW. center_cols: số cột đầu căn giữa."""
    assert sum(cols) == CW, 'tong be rong cot = %d, phai bang %d' % (sum(cols), CW)
    if caption:
        cp = doc.add_paragraph()
        _bang[0] += 1
        cp.add_run('Bảng %d. %s' % (_bang[0], caption)).italic = True
        cp.paragraph_format.space_before = Pt(6)
        cp.paragraph_format.space_after = Pt(2)
    tb = doc.add_table(rows=1, cols=len(headers))
    tb.style = 'Table Grid'
    tb.alignment = WD_TABLE_ALIGNMENT.LEFT
    for i, h in enumerate(headers):
        c = tb.rows[0].cells[i]
        set_cell(c, h, bold=True, white=True, size=size)
        shade(c, HDR_FILL)
    tb.rows[0]._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))  # lặp header qua trang
    for r in rows:
        cells = tb.add_row().cells
        for i, v in enumerate(r):
            set_cell(cells[i], '' if v is None else v, center=(i < center_cols), size=size)
    widths(tb, cols)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return tb


def add_code(lines, caption=None):
    """Sơ đồ ASCII / mã giả. Dùng Courier New 8pt, không dấu tiếng Việt để cột thẳng hàng."""
    if caption:
        cp = doc.add_paragraph()
        cp.add_run(caption).italic = True
        cp.paragraph_format.space_before = Pt(6)
        cp.paragraph_format.space_after = Pt(2)
    for ln in lines:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.0
        r = p.add_run(ln if ln else ' ')
        r.font.name = 'Courier New'
        r.font.size = Pt(8)
    doc.add_paragraph()


# ===================== 1. TRANG BÌA =====================
tables = doc.tables            # [0] Thông tin tài liệu, [1] Quản lý thay đổi, [2] ký FPT, [3] ký KH

_info = {_n(k): v for k, v in INFO.items()}
for row in tables[0].rows[1:]:
    key = _n(row.cells[0].text)
    if key in _info:
        set_cell(row.cells[1], _info[key])

# thêm dòng tên chức năng ngay dưới tiêu đề bìa (nhân bản đoạn tiêu đề để giữ định dạng)
for p in doc.paragraphs:
    if _n(p.text) == _n(COVER_TITLE):
        newp = copy.deepcopy(p._p)
        p._p.addnext(newp)
        np = Paragraph(newp, p._parent)
        for r in list(np.runs):
            r._r.getparent().remove(r._r)
        r = np.add_run(DOC_TITLE_LINES)
        r.bold = True
        r.font.size = Pt(16)
        np.alignment = WD_ALIGN_PARAGRAPH.CENTER
        break

# thêm 1 dòng vào bìa sẽ đẩy dòng "Hà Nội" sang trang sau -> bỏ bớt dòng trống sau bảng info
_removed, _after_table = 0, False
for p in list(doc.paragraphs):
    if _n(p.text).startswith(CITY_PREFIX):
        break
    if _n(p.text) == '' and _removed < 3:
        prev = p._p.getprevious()
        if prev is not None and prev.tag == qn('w:tbl'):
            _after_table = True
        if _after_table:
            p._p.getparent().remove(p._p)
            _removed += 1

for p in doc.paragraphs:
    if _n(p.text).startswith(CITY_PREFIX):
        for r in p.runs:
            r.text = ''
        p.runs[0].text = CITY_LINE
        break

# bảng Quản lý thay đổi: 2 dòng đầu là tiêu đề, dữ liệu từ dòng thứ 3
chg = tables[1]
while len(chg.rows) - 2 < len(CHANGE_LOG):
    chg.add_row()
for i, rowdata in enumerate(CHANGE_LOG):
    cells = chg.rows[2 + i].cells
    for j, v in enumerate(rowdata):
        set_cell(cells[j], v, center=(j in (0, 3)))
for r in chg.rows[2 + len(CHANGE_LOG):]:
    for c in r.cells:
        set_cell(c, '')

# trang ký: đổi tên khách hàng, xóa tên người của dự án mẫu trong template
for t in tables[2:4]:
    hdr = t.rows[0].cells[0]
    if 'ĐẠI DIỆN' in _n(hdr.text) and 'FPT' not in _n(hdr.text):
        set_cell(hdr, 'ĐẠI DIỆN ' + CUSTOMER, bold=True, white=True, center=True)
    for row in t.rows[2:]:
        set_cell(row.cells[1], '')

# ===================== 2. CẮT PHẦN THÂN MẪU =====================
children = list(body)
target = None
for p in doc.paragraphs:
    if _n(p.text) == _n(FIRST_HEADING) and p.style is not None and p.style.name == 'Heading 2':
        target = p._p
        break
assert target is not None, 'khong tim thay heading dau tien: ' + FIRST_HEADING

keep_sect = None
for ch in children[children.index(target):]:
    if ch.tag == qn('w:sectPr'):
        continue                       # sectPr cấp body: bỏ, dùng sectPr của section 1
    pPr = ch.find(qn('w:pPr'))
    if pPr is not None and keep_sect is None:
        inner = pPr.find(qn('w:sectPr'))
        if inner is not None:
            # sectPr của section 1 là cái DUY NHẤT có đủ headerReference/footerReference
            # cả 'default' lẫn 'first'. Lấy nhầm sectPr cuối -> trang 2 trở đi mất header/footer.
            keep_sect = copy.deepcopy(inner)
    body.remove(ch)
assert keep_sect is not None, 'khong lay duoc sectPr cua section 1'

old = body.find(qn('w:sectPr'))
if old is not None:
    body.remove(old)
body.append(keep_sect)


# ===================== 3. NỘI DUNG =====================
def build():
    """Viết nội dung ở đây. Khung 3 mục: xem references/section-structure.md.
    python-docx tự chèn đoạn/bảng mới TRƯỚC sectPr nên không cần xử lý gì thêm."""
    h2('TỔNG QUAN')
    h3('Mục đích tài liệu')
    add_p('<...>')
    h3('Phạm vi tài liệu')
    add_p('<...>')
    h3('Tài liệu tham chiếu')
    tbl(None, ['STT', 'Tên tài liệu', 'Người tạo', 'Ghi chú'],
        [['1', '<...>', '<...>', '<...>']],
        [700, 3100, 1700, 3574], 1)
    h3('Thuật ngữ viết tắt')
    tbl(None, ['STT', 'Thuật ngữ', 'Định nghĩa'],
        [['1', '<...>', '<...>']],
        [700, 2100, 6274], 1)

    h2('MÔ TẢ YÊU CẦU')
    # 2.1 Mục đích · 2.2 Quy trình nghiệp vụ liên quan · 2.3 Các giả định ·
    # 2.4 Rủi ro · 2.5 Ràng buộc · 2.6 Mô tả yêu cầu nghiệp vụ ·
    # 2.7 Format báo cáo/chứng từ · 2.8 Hình thức báo cáo/chứng từ

    h2('MÔ TẢ THIẾT KẾ CHỨC NĂNG')
    # 3.1 Thông tin chung · 3.2 Các bảng dữ liệu cần phát triển · 3.3 Tham số lọc ·
    # 3.4 Các màn hình chức năng · 3.5 Nội dung chi tiết báo cáo/chứng từ ·
    # (thêm 3.6+ cho logic nghiệp vụ, tích hợp, phân quyền, kiểm thử)


build()

# ===================== 4. LÀM MỚI MỤC LỤC =====================
# Mục lục trong template là field có cache của tài liệu mẫu. Đánh dấu dirty để Word
# tự cập nhật khi mở. KHÔNG dùng w:updateFields trong settings.xml — sai thứ tự schema.
for _instr in body.iter(qn('w:instrText')):
    if _instr.text and 'TOC' in _instr.text:
        for _fc in _instr.getparent().getparent().iter(qn('w:fldChar')):
            if _fc.get(qn('w:fldCharType')) == 'begin':
                _fc.set(qn('w:dirty'), 'true')
                break
        break

doc.save(OUT)
print('OK ->', OUT, '| so bang:', _bang[0])
