// ============================================================================
// TEMPLATE sinh tài liệu FS — dự án SAP S/4HANA Private Cloud (chuẩn MAG/Masterise)
//
// Cách dùng:
//   1. cp fs_lib.js + file này vào một thư mục ghi được (vd /tmp/fsgen)
//   2. Sửa phần META + HISTORY + phần NỘI DUNG bên dưới
//   3. NODE_PATH=/usr/local/lib/node_modules_global node build_fs_template.js
//   4. Validate + render PDF kiểm tra (xem SKILL.md mục "Sinh file và kiểm tra")
//
// Với FS dài (>1000 dòng nội dung), tách nội dung ra part2.js / part3.js:
//   - file này export { out, tbl, code, h1, h2, h3, P, PS }
//   - part2.js: const { tbl, h1, h2, P, PS } = require("./build.js");  rồi push tiếp
//   - main.js: require("./build.js"); require("./part2.js"); rồi buildFsDoc(...)
//   Bộ đếm "Bảng N" nằm trong closure của file này nên đánh số liên tục qua mọi part.
// ============================================================================

const fs = require("fs");
const { Paragraph, TextRun, HeadingLevel, AlignmentType } = require("docx");
const L = require("./fs_lib.js");
const {
  txt, p, heading, blankLine, buildTable, buildFsDoc, Packer,
  FONT, SZ_BODY, SZ_H1,
} = L;

// ===== Helper dựng nội dung ==================================================
let _bang = 0;
const out = [];

function h1(text) {                       // Mục cấp 1 — luôn sang trang mới
  out.push(new Paragraph({
    pageBreakBefore: true,
    heading: HeadingLevel.HEADING_1,
    children: [new TextRun({ text, font: FONT, size: SZ_H1, bold: true })],
    spacing: { before: 240, after: 120 },
  }));
}
const h2 = (t) => out.push(heading(t, 2));
const h3 = (t) => out.push(heading(t, 3));
const P = (t) => out.push(p(t));          // 1 đoạn văn
const PS = (arr) => arr.forEach((t) => out.push(p(t)));  // nhiều đoạn văn

// Khối mã / sơ đồ ASCII — Courier New 8pt, giữ nguyên khoảng trắng
function code(lines, caption) {
  if (caption) out.push(p(caption, { italics: true }));
  lines.forEach((line) =>
    out.push(new Paragraph({
      spacing: { before: 0, after: 0, line: 240 },
      children: [new TextRun({ text: line === "" ? " " : line, font: "Courier New", size: 16 })],
    }))
  );
  out.push(blankLine());
}

// Bảng — tự đánh số "Bảng N."; centerCols = số cột đầu căn giữa
// Tổng widths phải bằng 9922 (khổ A4 dọc, lề trái 2cm, các lề khác 1.5cm)
function tbl(caption, headers, rows, widths, centerCols) {
  out.push(p(`Bảng ${++_bang}. ${caption}`, { italics: true }));
  const cc = centerCols || 0;
  out.push(buildTable(
    [
      { header: true, cells: headers.map((x) => ({ content: x, align: AlignmentType.LEFT })) },
      ...rows.map((r) => ({
        cells: r.map((c, i) => ({
          content: String(c == null ? "" : c),
          align: i < cc ? AlignmentType.CENTER : AlignmentType.LEFT,
        })),
      })),
    ],
    widths
  ));
  out.push(blankLine());
}

// ===== META — SỬA PHẦN NÀY ===================================================
const meta = {
  // Header trang: trái = mã tài liệu, phải = phiên bản
  projectName: "MAG_SAP_2026_PM_FS_<PH>_<DOI_TUONG>",
  footerLeft:  "MAG SAP S/4 HANA",
  projectCode: "MAG_SAP_2026_PM",
  docCode:     "MAG_SAP_2026_PM_FS_<PH>_<DOI_TUONG>",
  docTitle:    "FS – <Tên chức năng>",
  module:      "<PH> – <Tên phân hệ đầy đủ>",
  version:     "V0.1",
  author:      "Đội dự án FPT",
  updateDate:  "<DD.MM.YYYY>",
  coverDateText: "tháng <M> năm <YYYY>",
  coverLines: [
    { text: "TÀI LIỆU THIẾT KẾ CHI TIẾT (FS)", size: 40 },
    { text: "<TÊN CHỨC NĂNG VIẾT HOA>", size: 32 },
    { text: "<PHẠM VI BỔ SUNG> – SAP S/4HANA MAG", size: 32 },
  ],
};

const history = [
  { date: "<DD.MM.YYYY>", section: "Toàn bộ tài liệu",
    description: "Tạo mới tài liệu thiết kế FS cho chức năng <...>",
    type: "T", version: "V0.1" },
];

// ===== NỘI DUNG — SỬA PHẦN NÀY ==============================================
// Bộ khung 13 mục chuẩn: xem references/section-structure.md

h1("1. TỔNG QUAN");
h2("1.1 Phạm vi tài liệu");
PS([
  "Tài liệu này mô tả chi tiết thiết kế của chức năng <...>, do FPT IS phát triển trên hệ thống SAP S/4HANA Private Cloud Edition cho Công ty Cổ phần Tập đoàn Masterise (MAG).",
  "Tài liệu là căn cứ để đội lập trình của FPT IS thực hiện cấu hình hệ thống và hiện thực các đối tượng phát triển, đồng thời là căn cứ để xây dựng tài liệu kiểm thử (Testscript) và tài liệu hướng dẫn sử dụng (User Manual) cho phần chức năng tương ứng.",
]);

h2("1.2 Ghi chú về mức độ xác thực của nội dung");
PS([
  "Toàn bộ thiết kế trong tài liệu này là đề xuất của FPT IS, CHƯA được kiểm chứng trên hệ thống thực tế của dự án MAG.",
  "Các phát biểu chưa kiểm chứng được đánh dấu [Unverified]; các phát biểu suy luận từ cơ chế của SAP được đánh dấu [Inference] ngay tại vị trí xuất hiện. Danh sách hạng mục BẮT BUỘC kiểm chứng trước khi lập trình tại mục <N>; danh sách điểm cần MAG xác nhận tại mục <N>.",
]);

h2("1.3 Thuật ngữ");
tbl("Danh mục thuật ngữ",
  ["STT", "Thuật ngữ", "Định nghĩa"],
  [["1", "<Thuật ngữ>", "<Định nghĩa>"]],
  [700, 2300, 6922], 1);

// ... các mục 2–13 (xem references/section-structure.md)

// ===== SINH FILE =============================================================
const outFile = `${meta.docCode}_v${meta.version.replace(/^V/, "")}.docx`;
Packer.toBuffer(buildFsDoc(meta, history, out)).then((buf) => {
  fs.writeFileSync(outFile, buf);
  console.log(`OK — ${outFile} — tổng số bảng: ${_bang}`);
});

module.exports = { out, tbl, code, h1, h2, h3, P, PS, bang: () => _bang };
