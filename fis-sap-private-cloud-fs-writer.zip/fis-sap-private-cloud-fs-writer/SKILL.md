---
name: fis-sap-private-cloud-fs-writer
description: "Viết, sinh, cập nhật, cắt gọt tài liệu Functional Specification (FS) dạng .docx cho dự án SAP S/4HANA Private Cloud / On-Premise của FIS, theo template chuẩn dự án Masterise (MAG). Chốt ranh giới FS/TS, khung mục và bẫy khi sinh file."
---

# FS Writer — SAP S/4HANA Private Cloud (chuẩn dự án MAG / Masterise)

## Phân biệt với skill khác

- Nền **Private Cloud / On-Premise** (append structure, customer exit, BAdI cổ điển, SM30) → skill này.
- Nền **S/4HANA Cloud Public Edition** (ABAP Cloud, released API, Key User Extensibility) →
  `fis-sap-public-cloud-fs-writer`.

Chưa rõ dự án chạy nền nào thì **hỏi trước khi viết** — kỹ thuật enhancement của hai nền khác nhau
hoàn toàn, viết nhầm nền là viết lại từ đầu.

## Quy trình

### 1. Xác định file template và file hiện hành — làm TRƯỚC MỌI THỨ

```bash
device_list_dir <thư mục dự án>        # tìm file *Temp_Form*.docx và các bản FS đang có
```

Có template của dự án (MAG: `MAG_SAP_2026_PM_FS Temp_Form.docx`) thì **bắt buộc dựng trên
template đó**, không sinh file từ đầu. Lý do và cách làm: `references/document-format.md` mục 0.

**Tốt hơn template rỗng: clone một FS THẬT đã bàn giao của cùng dự án** (MAG:
`MAG_SAP_2026_PM_FS_MM_GLDET_v0.1.docx`). File thật mang theo đúng bộ style đang dùng, đúng cách
đánh caption, đúng bề rộng bảng, và cho thấy dự án thực sự viết FS ở mức chi tiết nào. Cách clone:
bắt các paragraph mẫu (Heading 2, Heading 3, bullet, code, caption, Normal) và một bảng mẫu mỗi
số cột, rồi `deepcopy` khi sinh nội dung. **Bắt buộc**: bỏ paragraph Normal có `w:shd` khi chọn
mẫu, và strip `w:bookmarkStart/End` + `w:shd` trên mọi bản copy — xem `references/pitfalls.md`.

Người dùng có thể đã đổi tên file hoặc giữ bản `_OldVersion` — xác định bản hiện hành rồi mới
thao tác, và nói rõ sẽ ghi vào file nào. **Sửa tại chỗ trên file hiện hành, chỉ tăng version khi
được yêu cầu rõ.**

### 2. Làm rõ trước khi viết

Tối thiểu chốt bốn thứ: nền tảng · phạm vi áp dụng (những giao dịch / kênh tạo dữ liệu nào,
đừng quên kênh tích hợp) · nơi chứa cấu hình · các giá trị điều khiển được bật.

Dùng `AskUserQuestion`. Đừng hỏi những thứ tự đề xuất được — đề xuất kèm lý do rồi đưa vào mục
"Điểm cần xác nhận" để khách chốt sau.

### 3. Thiết kế giải pháp trước, viết tài liệu sau

Những điểm hay bị bỏ sót và phải chủ động nêu:

- Logic chạy ở **cấp nào** — cấp dòng chứng từ hay cấp dòng phân bổ / dòng con.
- Chuyện gì xảy ra khi **không tìm thấy** dữ liệu cấu hình (chặn / cảnh báo / im lặng — nên
  cấu hình được), và khi **người dùng đã nhập tay** (ghi đè / giữ nguyên — nên cấu hình được).
- **Thời điểm tính lại**: liệt kê rõ sự kiện nào tính lại, sự kiện nào KHÔNG. Hai bẫy kinh điển:
  tính lại ngay khi người dùng vừa sửa tay trường đích (họ vĩnh viễn không sửa được), và mở
  chứng từ cũ ở chế độ sửa rồi thoát cũng làm đổi dữ liệu theo bộ quy tắc mới.
- Kênh tích hợp đi qua **cùng một lớp logic** với kênh online.
- Khi bộ khóa có nhiều chiều wildcard: định nghĩa trình tự truy cập cố định; chiều "phạm vi tổ
  chức" đặt ở vòng ngoài. Xem `references/section-structure.md` mục 3.

#### Với FS tích hợp master data — bốn thứ luôn thiếu nếu không cố ý nghĩ tới

1. **Kiểm tra tồn tại trước khi tạo** — bản tin không nói rõ "tạo" hay "sửa", nên FS phải chỉ
   ra cách tra: tra theo mã hệ nguồn trong bảng ánh xạ, rồi tra theo mã đối tượng SAP nếu hệ
   nguồn gửi kèm. Thiếu bước này là lỗi thiết kế, không phải chi tiết kỹ thuật.
2. **Kiểm soát truy cập đồng thời** — hai bản tin cùng mã đến gần nhau đều thấy "chưa có" và
   đều tạo. Idempotency ở phía hệ nguồn KHÔNG chống được việc SAP tạo trùng. FS phải yêu cầu
   khoá logic theo mã nghiệp vụ (mô tả bằng ngôn ngữ nghiệp vụ, tên đối tượng khoá để TS đặt).
3. **Chiều trả về** — nếu bỏ mọi cơ chế dò trùng mờ (theo tên, đơn vị tính, nhóm hàng) thì việc
   hệ nguồn **gửi lại mã SAP** ở bản tin sau trở thành **yêu cầu tích hợp bắt buộc**, phải ghi
   thành một dòng Giả định kèm hậu quả nếu không có, không để là điểm chờ xác nhận.
4. **Mở rộng vùng dữ liệu tổ chức** — ai quyết định mở rộng sang tổ chức nào: hệ nguồn gửi,
   hay SAP suy từ bảng cấu hình. Nếu là bảng cấu hình thì nêu rõ khoá bảng và điều gì xảy ra
   khi thiếu dòng cấu hình.

### 4. Dựng file

```bash
mkdir -p /tmp/fsgen && cd /tmp/fsgen
cp "<thư mục dự án>/<FS thật hoặc Temp_Form>.docx" tpl.docx
cp <skill_dir>/scripts/fs_from_template.py build.py
# sửa phần CẤU HÌNH + hàm build() trong build.py
python3 build.py
```

`fs_from_template.py` đã xử lý sẵn: điền bìa, bảng Quản lý thay đổi, trang ký, cắt phần thân
mẫu, giữ đúng `sectPr` có header/footer, đánh dấu mục lục để Word tự làm mới, và các helper
`h2/h3/add_p/add_ps/tbl/add_code`.

Bìa còn một dòng địa danh tĩnh dạng `Hà Nội, MM/YYYY` — **phải ghi lại theo ngày tài liệu**,
nếu không nó giữ tháng của file mẫu.

Dự án không có template → phương án dự phòng bằng Node ở `references/document-format.md` mục 5.

### 5. Kiểm tra — không bỏ bước

```bash
python3 /mnt/skills/public/docx/scripts/office/validate.py <file>.docx
python3 /mnt/skills/public/docx/scripts/office/soffice.py --headless --convert-to pdf <file>.docx
pdftoppm -jpeg -r 70 -f <trang> -l <trang> <file>.pdf p
pdftotext <file>.pdf t.txt && grep -n "<nội dung vừa sửa>" t.txt
```

Bắt buộc mở ảnh xem bằng mắt: **trang bìa, trang ký, trang 2 (để chắc header/footer còn), một
bảng nhiều cột, một bảng dài tràn trang**. Lỗi vỡ chữ ở cột hẹp và lỗi mất header từ trang 2
chỉ lộ ra ở bước này. Xóa file PDF/JPG/txt tạm trước khi giao.

Thêm một bước grep **ngược** khi vừa lọc bớt nội dung: grep các từ khoá đáng lẽ đã bị bỏ
(tên bảng Z, `BAPI`, `ALV`, `SE11`, `SM30`, `LUW`) để chắc chúng thực sự không còn — trừ những
chỗ cố ý giữ, ví dụ dòng trong bảng Quản lý thay đổi mô tả việc đã bỏ.

### 6. Giao file

`SendUserFile` rồi `device_commit_files` vào thư mục dự án, sau đó xác nhận timestamp bằng
`device_bash: ls -l --time-style=+%H:%M:%S <file>`.

**Nếu commit bị từ chối vì file đang mở trong Word, nói ngay ở DÒNG ĐẦU câu trả lời** rằng chưa
ghi được và cần đóng file — đừng để lẫn vào giữa đoạn tổng kết.

Kèm một đoạn ngắn nêu: các quyết định thiết kế chính và lý do, những điểm chưa kiểm chứng, và
những chỗ mình tự quyết để người dùng phủ quyết được. Không mô tả lại nội dung tài liệu.

## Ranh giới FS / TS — quy tắc đã chốt

FS trả lời **hệ thống phải làm gì và làm trên dữ liệu nào**; TS trả lời **hiện thực thế nào**.

Đối chiếu bằng FS thật của dự án: `MAG_SAP_2026_PM_FS_MM_GLDET_v0.1.docx` **không có một tên
object Z nào**. Đó là mức chuẩn phải theo.

### FS phải có

- Cấu trúc dữ liệu ở mức trường cho mọi bảng và báo cáo phải xây dựng thêm:
  `Trường | Kiểu dữ liệu kèm ĐỘ DÀI | Khóa | Trường chuẩn tham chiếu | Diễn giải nghiệp vụ`.
- Logic chỉ đích danh **bảng/trường chuẩn của SAP** kèm mô tả nghiệp vụ — ví dụ `BUKRS CHAR 4 ·
  khóa · T001-BUKRS`, `KOSTL → CSKS (KOKRS, KOSTL, theo ngày tham chiếu) → CSKS-KOSAR`.
- **Mã interface** (`IF-MD10-01`, `IF-MD09-02`…) và **cấu trúc bản tin ở mức trường**: tên
  trường JSON, kiểu, độ dài, bắt buộc/tùy chọn, trường SAP đích. Đây là **hợp đồng liên hệ
  thống** — hai bên phải cùng đọc một tài liệu, nên nó thuộc FS chứ không phải TS.
- **Mã định danh nghiệp vụ do dự án cấp** vẫn giữ nguyên dạng kỹ thuật vì đó là **dữ liệu cấu
  hình**, không phải tên object: ID type (`Z001`, `Z002`, `ZHRMS`, `ZMDM`…), BP Role, BP Group,
  Material Type, mã hệ nguồn.

### FS không được có

Tên bảng Z, domain, data element, class, method, service, message class, package, tên BAdI /
customer exit, mã giả, delivery class, bộ đệm, transport, **đơn vị công việc (LUW) / COMMIT /
ROLLBACK / đối tượng khoá ENQUEUE**, **ước lượng khối lượng phát triển (MD)**, **danh mục đối
tượng phát triển**.

Trường mới chưa có tên thì đặt tên gợi ý kèm câu *"tên kỹ thuật cuối cùng do TS đặt theo quy ước
của dự án"*.

### Cách diễn đạt thay thế — dùng nguyên văn

| Trong TS | Trong FS |
|---|---|
| bảng `ZMD_MATDEF` | "Bảng cấu hình giá trị mặc định" |
| bảng `ZMD_XREF` | "Bảng ánh xạ mã" |
| `ZMD-ENH-01` | "KS-01" (mã kiểm soát nghiệp vụ) |
| gọi BAPI/API chuẩn | "giao dịch ghi chuẩn của SAP" |
| service Z tiếp nhận | "service tiếp nhận bản tin" |
| một đơn vị công việc | "một giao dịch ghi" (ghi trọn vẹn hoặc không ghi gì) |
| ROLLBACK | "hoàn tác" |
| SM30 | "giao dịch bảo trì bảng cấu hình" |
| báo cáo ALV | "danh sách kết quả" |
| enhancement | "kiểm soát trên giao dịch" |

Khi lọc bằng script: thay theo **cụm dài trước cụm ngắn**, khớp theo biên từ, và **danh sách
loại trừ** cho ID type / BP Role / bảng chuẩn SAP — nếu không sẽ đổi luôn `ZMDM` (ID type) thành
tên nghiệp vụ và làm sai hợp đồng bản tin.

### Hai mục chuyển hẳn sang TS

"Danh mục đối tượng phát triển" (có cột MD và dòng tổng) và "Kiểm chứng bắt buộc trước khi lập
trình" (PoC-01…) **thuộc TS**. Khi cắt hai mục này khỏi FS, phải cứu nội dung: mọi cảnh báo
`[Unverified]` đang neo vào một dòng PoC phải viết lại thành câu văn đầy đủ trong mục Giả định
hoặc ngay tại chỗ, không được bỏ luôn ý.

Mục **"Phụ lục – Giả định và các điểm cần xác nhận"** (ĐM-01…, có cột mức độ Chặn / Cao /
Trung bình) **ở lại FS** — đó là việc của khách hàng, không phải của DEV.

Chi tiết và khung 3 mục: `references/section-structure.md`.

## Khi người dùng yêu cầu cắt gọt tài liệu

Đây là phần việc chiếm nhiều lượt nhất. Ba việc phải làm mỗi lần bỏ một mục hoặc một dòng:

1. **Quét tham chiếu chéo** — grep số mục và mã (GĐ-xx, V-xx, ĐM-xx, KS-xx, SRCRULE 0x) vừa bỏ,
   sửa hết những chỗ trỏ tới. Không để mã treo.
2. **Cứu nội dung có giá trị nằm nhờ** trong mục sắp xóa, chuyển sang mục khác và **nói rõ đã
   chuyển đi đâu**, để người dùng phủ quyết được nếu không muốn.
3. **Không tự đánh số lại mã đã dùng** trừ khi có lý do rõ; nếu đánh lại thì cập nhật mọi tham
   chiếu và nói cho người dùng biết.

Khi bỏ một cơ chế kiểm soát, luôn tự hỏi **cơ chế nào đang dựa vào nó**. Bỏ dò trùng mờ thì
phần đối soát mất đầu vào → phải bù bằng một yêu cầu tích hợp mới, và nói rõ điều đó cho người
dùng chứ đừng im lặng bỏ.

## Kỷ luật nội dung

**Nói thật về những gì chưa chắc chắn.** Đánh nhãn `[Inference]` / `[Unverified]` ngay tại chỗ.
Nếu tài liệu có mục Các giả định thì mỗi nhãn phải có một dòng tương ứng kèm ảnh hưởng nếu sai;
nếu người dùng bỏ mục đó, chuyển cảnh báo thành câu văn đầy đủ chứ đừng bỏ luôn ý.

**Tự soát lại thiết kế của mình bằng khoá bảng chuẩn.** Trước khi khai một bảng cấu hình có
chiều tổ chức, kiểm khoá bảng SAP tương ứng: `MVKE` chỉ có `VKORG + VTWEG` — division là
`MARA-SPART` ở mức client, đưa division vào khoá vùng bán hàng là sai. Khi phát hiện mình sai,
nói ra và sửa, đừng lặng lẽ ghi đè.

**Cấu hình và dữ liệu là hai chuyện khác nhau.** Có thể cấu hình ở mức chi tiết hơn mức dữ liệu
thực dùng — ví dụ valuation area ở mức plant nhưng mọi plant trong cùng company code dùng chung
một valuation class. Khi đó bảng cấu hình phải khoá theo mức **dữ liệu** (company code) để cấu
trúc bảng tự ép tính nhất quán, và ghi rõ vì sao không khoá theo plant.

**Giải thích vì sao, không chỉ cái gì.** Mọi lựa chọn trông giống thiếu sót cần một đoạn nêu lý
do và một câu khẳng định đó là chủ ý.

**Cấu hình thay vì hard-code.** Danh sách loại chứng từ được bật, chế độ ghi đè, mức thông báo
— đưa hết vào bảng khai báo. Khi mỗi giá trị cần nhiều thuộc tính đi kèm thì dùng bảng Z chứ
đừng dùng TVARVC: TVARVC chỉ chứa được danh sách giá trị, mọi thuộc tính khác sẽ rơi ngược vào
mã nguồn.

**Ngôn ngữ.** Tiếng Việt, giữ nguyên thuật ngữ kỹ thuật tiếng Anh; không dịch tên bảng, trường,
transaction.

## Trước khi giao — checklist

- [ ] Dựng trên file template hoặc FS thật của dự án (nếu dự án có).
- [ ] Tên file và mã tài liệu theo `references/naming.md`; chỉ tăng version khi được yêu cầu.
- [ ] Trang ký đã đổi tên khách hàng và xóa tên người của dự án mẫu; dòng địa danh trên bìa
      đã khớp ngày tài liệu.
- [ ] Bảng: header nền `1F4E79` chữ trắng, lặp header qua trang, tổng bề rộng cột = 9074.
- [ ] Cột chứa mã (`PoC-01`, `ĐM-10A`) và cột ngày rộng đủ để không vỡ chữ.
- [ ] Caption `Bảng N.` liên tục; sơ đồ đánh số riêng `Sơ đồ N.`.
- [ ] Đã grep xác nhận nội dung vừa sửa/xóa thực sự có/không còn trong file PDF, kể cả grep
      ngược các từ khoá thuộc TS.
- [ ] FS không còn tên object Z, LUW, MD, danh mục đối tượng phát triển; ID type / BP Role /
      bảng chuẩn SAP vẫn nguyên.
- [ ] `validate.py` PASSED; đã render và soi mắt bìa + trang ký + trang 2 + bảng rộng nhất.
- [ ] Đã xóa file tạm; đã `device_commit_files` và xác nhận timestamp.

`references/pitfalls.md` — danh sách bẫy đã va phải, đọc trước khi viết script sửa file.