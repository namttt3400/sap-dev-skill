"""MCP server expose SAP GUI Scripting cho Claude."""
from mcp.server.fastmcp import FastMCP
import sap_gui

mcp = FastMCP("sap-gui")


@mcp.tool()
def sap_info() -> dict:
    """Trả thông tin session SAP GUI hiện tại (system, client, user, transaction)."""
    return sap_gui.info()


@mcp.tool()
def sap_run_tcode(tcode: str) -> str:
    """Gõ T-code và Enter trong SAP GUI session đang mở.
    
    Args:
        tcode: T-code, ví dụ 'VA03', 'MM03', 'F-02'
    
    Returns:
        Nội dung status bar sau khi chạy.
    """
    return sap_gui.run_tcode(tcode)


@mcp.tool()
def sap_set_field(field_id: str, value: str) -> str:
    """Set giá trị một field trên màn hình hiện tại.
    
    Args:
        field_id: ID của field (lấy từ Script Recording), ví dụ 'wnd[0]/usr/ctxtVBAK-VBELN'
        value: giá trị string cần điền
    """
    return sap_gui.set_field(field_id, value)


@mcp.tool()
def sap_get_field(field_id: str) -> str:
    """Đọc giá trị hiện tại của một field."""
    return sap_gui.get_field(field_id)


@mcp.tool()
def sap_press(button_id: str) -> str:
    """Bấm một button trên màn hình.
    
    Args:
        button_id: ID của button. Phổ biến:
            'wnd[0]/tbar[0]/btn[0]'  = Enter
            'wnd[0]/tbar[0]/btn[3]'  = Back (F3)
            'wnd[0]/tbar[0]/btn[8]'  = Execute (F8)
            'wnd[0]/tbar[0]/btn[11]' = Save (Ctrl+S)
    """
    return sap_gui.press(button_id)


@mcp.tool()
def sap_send_key(vkey: int = 0) -> str:
    """Gửi virtual key. 0=Enter, 3=Back, 8=Execute, 11=Save."""
    return sap_gui.send_key(vkey)


@mcp.tool()
def sap_status_bar() -> str:
    """Đọc status bar (message hiện ở đáy màn hình)."""
    return sap_gui.status_bar()


@mcp.tool()
def sap_screen_dump() -> str:
    """Trả về text của các field trên màn hình hiện tại. Dùng để debug khi không biết field ID."""
    return sap_gui.screenshot_text()


if __name__ == "__main__":
    mcp.run()