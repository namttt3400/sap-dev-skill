import win32com.client


def _session():
    """Lấy session SAP GUI đầu tiên đang mở. Raise nếu không có."""
    sap_gui = win32com.client.GetObject("SAPGUI")
    app = sap_gui.GetScriptingEngine
    if app.Children.Count == 0:
        raise RuntimeError("Không có SAP connection nào đang mở")
    conn = app.Children(0)
    if conn.Children.Count == 0:
        raise RuntimeError("Connection chưa có session")
    return conn.Children(0)


def info() -> dict:
    """Trả thông tin session hiện tại."""
    s = _session()
    return {
        "system": s.Info.SystemName,
        "client": s.Info.Client,
        "user": s.Info.User,
        "transaction": s.Info.Transaction,
        "language": s.Info.Language,
    }


def run_tcode(tcode: str) -> str:
    """Gõ T-code và Enter. Trả về status bar."""
    s = _session()
    s.findById("wnd[0]/tbar[0]/okcd").text = f"/n{tcode}"
    s.findById("wnd[0]").sendVKey(0)
    return status_bar()


def set_field(field_id: str, value: str) -> str:
    """Set giá trị một field. field_id lấy từ Script Recording."""
    s = _session()
    elem = s.findById(field_id)
    elem.text = str(value)
    return f"Set {field_id} = {value}"


def get_field(field_id: str) -> str:
    """Đọc giá trị một field."""
    s = _session()
    return s.findById(field_id).text


def press(button_id: str) -> str:
    """Bấm một button. Trả về status bar."""
    s = _session()
    s.findById(button_id).press()
    return status_bar()


def send_key(vkey: int = 0) -> str:
    """Gửi virtual key. 0=Enter, 3=F3 (back), 8=F8 (execute), 11=Save, 12=F12 (cancel)."""
    s = _session()
    s.findById("wnd[0]").sendVKey(vkey)
    return status_bar()


def status_bar() -> str:
    """Đọc status bar (dòng message dưới đáy màn hình)."""
    s = _session()
    try:
        sb = s.findById("wnd[0]/sbar")
        return f"[{sb.MessageType}] {sb.Text}" if sb.Text else ""
    except Exception:
        return ""


def screenshot_text() -> str:
    """Trả về toàn bộ text các field trên màn hình hiện tại (debug)."""
    s = _session()
    result = []
    def walk(elem, depth=0):
        try:
            if elem.Type in ("GuiTextField", "GuiCTextField", "GuiLabel"):
                result.append(f"{elem.Id} = {elem.Text}")
        except Exception:
            pass
        try:
            for child in elem.Children:
                walk(child, depth+1)
        except Exception:
            pass
    walk(s.findById("wnd[0]"))
    return "\n".join(result[:100])  # giới hạn 100 dòng