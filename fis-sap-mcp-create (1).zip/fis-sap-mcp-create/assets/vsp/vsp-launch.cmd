@echo off
rem ===================================================================
rem  vsp-launch.cmd <SystemName>
rem  Launcher cho MCP vsp (S/4HANA Public Cloud) - doc credential tu
rem  C:\sap-mcp\.env roi bat dau vsp.exe o che do SAML (khong can browser).
rem  Dung trong manifest .dxt:  cmd.exe /c C:\sap-mcp\vsp-launch.cmd KTQ_Dev
rem ===================================================================
setlocal EnableExtensions DisableDelayedExpansion

set "VSP=C:\sap-mcp\vsp-dxt\vsp.exe"
set "ENVFILE=C:\sap-mcp\.env"

for /f "usebackq eol=# tokens=1,* delims==" %%A in ("%ENVFILE%") do set "%%A=%%B"

set "SYS=%~1"
set "URL="
set "CLIENT="
set "SAMLUSER="
set "SAMLPASS="
set "COOKIE="

if /i "%SYS%"=="Casla_Dev"  goto :casla_dev
if /i "%SYS%"=="Casla_Cus"  goto :casla_cus
if /i "%SYS%"=="HTIT_DEV"   goto :htit_dev
echo vsp-launch: unknown system "%SYS%" 1>&2
exit /b 2

:casla_dev
set "URL=https://my426517.s4hana.cloud.sap"
set "CLIENT=080"
set "SAMLUSER=%CASLA_SAML_USER%"
set "SAMLPASS=%CASLA_SAML_PASSWORD%"
set "COOKIE=C:\sap-mcp\vsp-cookies.txt"
goto :run

:casla_cus
set "URL=https://my426501.s4hana.cloud.sap"
set "CLIENT=100"
set "SAMLUSER=%CASLA_SAML_USER%"
set "SAMLPASS=%CASLA_SAML_PASSWORD%"
set "COOKIE=C:\sap-mcp\vsp-cookies-cus.txt"
goto :run

:htit_dev
set "URL=https://my428934.s4hana.cloud.sap"
set "CLIENT=080"
set "SAMLUSER=%HTIT_SAML_USER%"
set "SAMLPASS=%HTIT_SAML_PASSWORD%"
set "COOKIE=C:\sap-mcp\vsp-cookies-htit-dev.txt"
goto :run

:run
if not defined SAMLUSER (
  echo vsp-launch: thieu credential cho %SYS% trong %ENVFILE% 1>&2
  exit /b 3
)
"%VSP%" --url "%URL%" --client "%CLIENT%" --language EN --saml-auth --saml-user "%SAMLUSER%" --saml-password "%SAMLPASS%" --cookie-save "%COOKIE%" --mode expert --enable-transports --allow-transportable-edits %~2 %~3
exit /b %ERRORLEVEL%
