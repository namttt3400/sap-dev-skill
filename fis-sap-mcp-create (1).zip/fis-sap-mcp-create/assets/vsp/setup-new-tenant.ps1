# =====================================================================
#  setup-new-tenant.ps1  -  them 1 tenant Public Cloud vao MCP vsp
#  Pattern: .env (credential) + vsp-launch.cmd (launcher) + .dxt (thin)
#  Auth: vsp --saml-auth  =>  KHONG mo browser, khong lo cookie het han.
#  Password nhap tai cho (Read-Host -AsSecureString), KHONG nam trong
#  lich su chat / khong truyen qua AI.
#  ==> SUA 7 BIEN duoi day roi chay:
#      powershell -ExecutionPolicy Bypass -File setup-new-tenant.ps1
# =====================================================================
$ErrorActionPreference = 'Stop'
$enc = New-Object System.Text.UTF8Encoding($false)

$Sys      = 'HTIT_DEV'                                  # ten he (= display_name = tham so launcher)
$Url      = 'https://my428934.s4hana.cloud.sap'         # base URL tenant (KHONG co /ui)
$Client   = '080'                                       # doan dung: dev tenant 080 / cus 100 - script tu sua neu cookie khac
$User     = 'anhlh73@fpt.com'                           # user IAS (email)
$Prefix   = 'HTIT'                                      # tien to bien trong .env: <Prefix>_SAML_USER / _PASSWORD
$Cookie   = 'C:\sap-mcp\vsp-cookies-htit-dev.txt'
$DxtName  = 'vsp-htit-dev'                              # field name trong manifest

$EnvFile  = 'C:\sap-mcp\.env'
$Launcher = 'C:\sap-mcp\vsp-launch.cmd'
$Vsp      = 'C:\sap-mcp\vsp-dxt\vsp.exe'
$BuildDir = "C:\sap-mcp\build-$DxtName"
$OutDxt   = "C:\sap-mcp\$Sys.dxt"
$Label    = ($Sys.ToLower())
$ts       = Get-Date -Format 'yyyyMMdd-HHmmss'

# ---------- 1) credential vao .env ----------------------------------
Write-Host "`n[1/5] Credential trong $EnvFile" -ForegroundColor Cyan
$envTxt = Get-Content $EnvFile -Raw
if ($envTxt -notmatch "${Prefix}_SAML_PASSWORD=") {
    $sec = Read-Host "  Nhap password IAS cho $User" -AsSecureString
    $pw  = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
             [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
    Copy-Item $EnvFile "$EnvFile.bak-$ts" -Force
    $add = "`r`n# --- $Sys ($Url) ---`r`n${Prefix}_SAML_USER=$User`r`n${Prefix}_SAML_PASSWORD=$pw`r`n"
    [IO.File]::WriteAllText($EnvFile, ($envTxt.TrimEnd() + $add), $enc)
    Write-Host "  OK - da them ${Prefix}_SAML_USER / _PASSWORD" -ForegroundColor Green
} else { Write-Host "  Da co san, bo qua." -ForegroundColor Green }

# ---------- 2) patch vsp-launch.cmd ---------------------------------
Write-Host "[2/5] Patch $Launcher" -ForegroundColor Cyan
$lc = Get-Content $Launcher -Raw
if ($lc -notmatch ":$Label") {
    Copy-Item $Launcher "$Launcher.bak-$ts" -Force
    $disp = 'if /i "%SYS%"=="' + $Sys + '" goto :' + $Label + "`r`n"
    # chen dong dispatch ngay truoc dong 'echo vsp-launch: unknown system'
    $lc = $lc -replace '(?m)^(echo vsp-launch: unknown system)', ($disp + '$1')
    $blk = @"
:$Label
set "URL=$Url"
set "CLIENT=$Client"
set "SAMLUSER=%${Prefix}_SAML_USER%"
set "SAMLPASS=%${Prefix}_SAML_PASSWORD%"
set "COOKIE=$Cookie"
goto :run

"@
    $lc = $lc -replace '(?m)^:run\r?\n', ($blk + ":run`r`n")
    [IO.File]::WriteAllText($Launcher, $lc, (New-Object System.Text.ASCIIEncoding))
    Write-Host "  OK - da them nhanh :$Label" -ForegroundColor Green
} else { Write-Host "  Da co nhanh :$Label, bo qua." -ForegroundColor Green }

# ---------- 3) test SAML auth (khong browser) + do client ------------
Write-Host "[3/5] Test SAML auth qua launcher..." -ForegroundColor Cyan
Remove-Item $Cookie -ErrorAction SilentlyContinue
$p = Start-Process 'cmd.exe' -ArgumentList @('/c',$Launcher,$Sys) -WindowStyle Hidden -PassThru `
       -RedirectStandardError "C:\sap-mcp\$Label-err.log" -RedirectStandardOutput "C:\sap-mcp\$Label-out.log"
for ($i=0; $i -lt 45; $i++) { if (Test-Path $Cookie) { break }; Start-Sleep 1 }
Start-Sleep 2
Get-Process -Id $p.Id -ErrorAction SilentlyContinue | Stop-Process -Force
Get-Process vsp -ErrorAction SilentlyContinue | Where-Object { $_.StartTime -gt (Get-Date).AddMinutes(-2) } |
    Stop-Process -Force -ErrorAction SilentlyContinue

if (Test-Path $Cookie) {
    $sid = (Select-String -Path $Cookie -Pattern 'SAP_SESSIONID_[A-Z0-9]+_\d{3}' -AllMatches).Matches.Value | Select-Object -First 1
    Write-Host "  OK - SAML auth thanh cong. Cookie: $sid" -ForegroundColor Green
    if ($sid -match '_(\d{3})$' -and $Matches[1] -ne $Client) {
        $real = $Matches[1]
        Write-Host "  !! Client thuc te $real (khong phai $Client) - dang sua launcher" -ForegroundColor Yellow
        $lc2 = Get-Content $Launcher -Raw
        $lc2 = $lc2 -replace "(?s)(:$Label.*?set `"CLIENT=)\d{3}", ('${1}' + $real)
        [IO.File]::WriteAllText($Launcher, $lc2, (New-Object System.Text.ASCIIEncoding))
        $Client = $real
    }
} else {
    Write-Host "  THAT BAI - khong lay duoc cookie. Log:" -ForegroundColor Red
    Get-Content "C:\sap-mcp\$Label-err.log" -Tail 20 -ErrorAction SilentlyContinue
    Write-Host "  -> DUNG lai, dung cai extension khi chua auth duoc." -ForegroundColor Red
}

# ---------- 4) dong goi .dxt (khong chua password) ------------------
Write-Host "[4/5] Dong goi $OutDxt" -ForegroundColor Cyan
New-Item -ItemType Directory -Force $BuildDir | Out-Null
Copy-Item $Vsp "$BuildDir\vsp.exe" -Force
$m = [ordered]@{
  manifest_version = '0.3'
  name         = $DxtName
  display_name = $Sys
  version      = '0.1.0'
  description  = "vsp ADT bridge - $Sys ($Url)."
  author       = @{ name = 'FIS' }
  server = [ordered]@{
    type = 'binary'; entry_point = 'vsp.exe'
    mcp_config = [ordered]@{ command = 'cmd.exe'; args = @('/c', $Launcher, $Sys) }
  }
  compatibility = @{ platforms = @('win32') }
  license = 'MIT'
}
[IO.File]::WriteAllText("$BuildDir\manifest.json", ($m | ConvertTo-Json -Depth 10), $enc)
Compress-Archive -Path "$BuildDir\manifest.json","$BuildDir\vsp.exe" -DestinationPath "$BuildDir.zip" -Force
Move-Item "$BuildDir.zip" $OutDxt -Force
Write-Host ("  OK - {0:N1} MB" -f ((Get-Item $OutDxt).Length/1MB)) -ForegroundColor Green

# ---------- 5) profile CLI + verify ---------------------------------
Write-Host "[5/5] Them he $Sys vao ~\.vsp.json + verify" -ForegroundColor Cyan
$pf = "$env:USERPROFILE\.vsp.json"
$cfg = Get-Content $pf -Raw | ConvertFrom-Json
$cfg.systems | Add-Member -NotePropertyName $Sys -NotePropertyValue ([pscustomobject]@{
    url = $Url; client = $Client; language = 'EN'; cookie_file = $Cookie }) -Force
[IO.File]::WriteAllText($pf, ($cfg | ConvertTo-Json -Depth 20), $enc)
& $Vsp -s $Sys search "Z*" 2>&1 | Select-Object -First 12

Write-Host "`n=== XONG === Settings > Extensions > Advanced > Install extension -> $OutDxt" -ForegroundColor Yellow
Write-Host "Roi RESTART HAN Claude Desktop. Tool len namespace: mcp__${Sys}__*" -ForegroundColor Yellow
