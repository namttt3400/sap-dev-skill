---
name: fis-sap-mcp-create
description: >-
  Hướng dẫn TẠO / CÀI / SỬA MCP server kết nối SAP trong Claude Desktop (Cowork) bằng extension .dxt. LUÔN
  dùng khi người dùng nói: "tạo mcp sap", "tạo mcp connect sap", "cài mcp vsp", "thêm tenant vsp", "kết nối
  public cloud / private cloud", "tạo mcp sap gui", "đăng nhập không cần browser", "tự điền user pass",
  "saml-auth", "refresh cookie vsp", "cookie hết hạn suốt", "đổi tên namespace mcp", "mcp báo could not
  connect", "cài .dxt". Bao gồm cơ chế .dxt + extensions-installations.json, cài qua Settings Extensions
  (KHÔNG inject tay), display_name thành namespace tool; Public Cloud TỰ LOGIN SAML programmatic (saml-auth +
  .env + vsp-launch.cmd, không cần browser, không lo cookie hết hạn) và browser-auth cookie SSO dự phòng, dò
  client/SID từ cookie; on-prem basic auth (HTTPS 44300 + insecure, tránh HTTP 8000 redirect FQDN); server
  Python FastMCP (sap-gui); server Node build từ source (mcp-abap-adt/mario); profile CLI .vsp.json; quirk
  verify (GetSystemInfo, CSRF).
---

# Tạo MCP kết nối SAP trong Claude Desktop (Cowork)

Skill đúc kết cách tạo/cài/sửa các MCP SAP: **vsp (Vibing Steampunk)** — ADT<->MCP bridge cho ABAP
(Public Cloud & on-prem), và **sap-gui** — server Python điều khiển SAP GUI Scripting. Tất cả cài dưới
dạng **extension .dxt** (bền), KHÔNG dùng claude_desktop_config.json mcpServers (app tự xoá khi restart).

Đường dẫn quy ước máy này: C:\sap-mcp\ (binary, cookie, build), dự án D:\AI\AI_PROJECT.

## 0. Nguyên tắc VÀNG (đọc trước khi làm)

1. KHÔNG dùng claude_desktop_config.json mcpServers — Claude Desktop bản này TỰ GHI ĐÈ file đó khi restart
   và XÓA SẠCH mcpServers thêm tay. Chỉ dùng extension .dxt.
2. KHÔNG inject tay vào %APPDATA%\Claude\extensions-installations.json + tạo folder rồi restart — app KHÔNG
   launch extension đăng ký kiểu đó (trạng thái enabled nằm ở store nội bộ mã hoá riêng). Nếu sau đó xoá
   folder thì app báo "Could not connect to MCP server". Luôn cài qua UI.
3. App cache args extension lúc khởi động: kill + respawn process KHÔNG áp dụng thay đổi args/manifest;
   mọi thay đổi (client, url, đăng ký mới, đổi display_name) CHỈ có hiệu lực sau khi RESTART HẲN Claude Desktop.
4. display_name KHÔNG chứa ký tự đặc biệt (đặc biệt là "/") vì sẽ vỡ việc tạo folder/log dẫn tới
   "could not connect". Namespace tool = display_name thay khoảng trắng bằng "_" -> mcp__<Display_Name>__<tool>.
5. Ghi file cấu hình JSON UTF-8 KHÔNG BOM (.vsp.json, manifest, installations.json). BOM gây lỗi
   invalid character. Backup extensions-installations.json trước khi sửa (file từng bị corrupt).
6. Mật khẩu / cookie là secret: nằm plaintext trong manifest/.vsp.json — chấp nhận ở mức file cục bộ,
   KHÔNG commit/chia sẻ, KHÔNG lưu vào memory.
7. Manifest .dxt 0.3 BẮT BUỘC field "author" — thiếu sẽ lỗi Install "Invalid manifest: author: Required".
11. **NHẮC CHỦ ĐỘNG — rà soát MCP còn phải mở browser.** Bất cứ khi nào làm việc với MCP SAP (tạo mới,
   sửa, gặp lỗi auth, hoặc user chỉ nói chung "mcp"), CHẠY bước rà soát ở **mục 2C**. Nếu thấy MCP nào còn
   `--browser-auth` / `--cookie-file` (tức vẫn phải mở browser và sẽ hết hạn cookie) thì:
   - **NÓI NGAY cho user** danh sách MCP đó (kể cả khi user không hỏi tới) — đây là nợ kỹ thuật, mỗi lần cookie
     hết hạn là mất thời gian.
   - **ĐỀ XUẤT chuyển sang SAML** (mục 2B) và làm luôn nếu user đồng ý: thêm biến vào `.env` → thêm nhánh vào
     `vsp-launch.cmd` → trỏ manifest sang `cmd.exe /c vsp-launch.cmd <System>` → restart.
   - Chỉ giữ browser-auth khi IdP của tenant đó **thật sự bắt MFA** — ghi rõ lý do cho user biết.

9. Public Cloud: MẶC ĐỊNH dùng SAML programmatic (mục 2B) — cờ `--saml-auth` + credential trong
   `C:\sap-mcp\.env` + launcher `vsp-launch.cmd`. KHÔNG mở browser, KHÔNG bao giờ phải refresh cookie tay.
   browser-auth (mục 2) chỉ còn là DỰ PHÒNG khi IdP bật MFA hoặc SAML flow thất bại.
10. Secret KHÔNG được đi qua câu lệnh của AI: classifier bảo mật của Claude CHẶN mọi lệnh
   Windows-MCP/PowerShell/Bash chứa credential (kể cả `Start-Process` launch 1 script có literal
   credential, kể cả `Get-Content` thô trên file có secret). Hệ quả bắt buộc:
   - Đọc file có secret → luôn mask trước bằng `-replace` (che phần sau dấu `=`) rồi mới in.
   - Nhập secret → để SCRIPT tự hỏi trên máy user (`Read-Host -AsSecureString`), AI chỉ launch script
     KHÔNG chứa literal secret (xem `assets/vsp/setup-new-tenant.ps1`).

8. LUÔN thêm cờ transport vào args vsp (cả Public Cloud & on-prem): `--enable-transports` (cho phép
   CreateTransport/ListTransports/GetUserTransports) và `--allow-transportable-edits` (cho phép tạo/sửa
   object trong package transportable). MẶC ĐỊNH vsp CHẶN mọi thao tác transport → không tạo được TR,
   không tạo được object non-$; thiếu cờ sẽ gặp: "transports not enabled" và "editing transportable objects
   is disabled ... require explicit opt-in". Đổi args phải RESTART hẳn Claude Desktop (rule 3). Nếu extension
   đã cài mà thiếu cờ: sửa args ở CẢ manifest.json trong folder extension VÀ extensions-installations.json
   (key theo id), UTF-8 no BOM, rồi restart.

## 1. Đóng gói extension .dxt (khung chung)

.dxt = file ZIP chứa manifest.json + các file server. Manifest tối thiểu (manifest_version 0.3):

    {
      "manifest_version": "0.3",
      "name": "<id-kebab>",
      "display_name": "<Ten Hien Thi Khong Co Ky Tu Dac Biet>",
      "version": "0.1.0",
      "description": "...",
      "author": { "name": "FIS" },
      "server": {
        "type": "binary",
        "entry_point": "vsp.exe",
        "mcp_config": {
          "command": "${__dirname}/vsp.exe",
          "args": ["--url","...","--client","100","--mode","expert","--enable-transports","--allow-transportable-edits"]
        }
      },
      "compatibility": { "platforms": ["win32"] },
      "license": "MIT"
    }

Đóng gói (PowerShell), rồi copy ra D:\AI\AI_PROJECT để present_files:

    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText("$bd\manifest.json", $manifest, $enc)
    Compress-Archive -Path "$bd\manifest.json","$bd\vsp.exe" -DestinationPath "$bd.zip" -Force
    Move-Item "$bd.zip" "C:\sap-mcp\<name>.dxt" -Force
    Copy-Item "C:\sap-mcp\<name>.dxt" "D:\AI\AI_PROJECT\<name>.dxt" -Force

Kiểm tra nội dung .dxt bằng [System.IO.Compression.ZipFile]::OpenRead(...) (Expand-Archive kén đuôi .dxt).

### Cài đặt (luôn qua UI + restart)
1. Settings > Extensions > Advanced > Install extension -> chọn file .dxt.
2. Bật extension nếu cần -> đóng và mở lại HẲN Claude Desktop.
3. Sau restart, tool xuất hiện dưới namespace mcp__<Display_Name>__* (space -> "_").

### Đổi tên namespace (display_name) extension đã cài
Sửa display_name ở CẢ HAI: manifest.json trong folder extension VÀ manifest trong
extensions-installations.json (key theo id), ghi UTF-8 no BOM, rồi restart app.

## 2. vsp — Public Cloud (S/4HANA Cloud Public Edition)

> ⚠️ ĐỌC MỤC **2B** TRƯỚC. Từ 2026-08-14 cách chuẩn là **SAML programmatic (không browser)**.
> Mục 2 này chỉ dùng khi 2B thất bại (IdP bắt MFA) hoặc cần lấy cookie 1 lần để dò client/SID.

Auth bằng browser SSO cookie (KHÔNG basic auth). Mỗi tenant 1 cookie file riêng.

Lấy/refresh cookie (browser-auth):

    # Edge (mặc định, thường tự SSO nếu đã đăng nhập):
    vsp.exe --url https://<tenant>.s4hana.cloud.sap --browser-auth --cookie-save C:\sap-mcp\<file>.txt
    # Chrome (khi Edge không có sẵn SSO): dùng SHORT PATH 8.3 vì đường dẫn có dấu cách
    $cs = (New-Object -ComObject Scripting.FileSystemObject).GetFile("$env:ProgramFiles\Google\Chrome\Application\chrome.exe").ShortPath
    Start-Process vsp.exe -ArgumentList @('--url','https://<tenant>','--browser-auth','--browser-exec',$cs,'--browser-auth-timeout','3m','--cookie-save','C:\sap-mcp\<file>.txt')

- Chrome đang mở sẵn (đã login) -> mở tab trong cửa sổ hiện có, auto-SSO.
- Phát hiện client từ tên cookie: SAP_SESSIONID_AK3_<client> (vd ..._080 -> client 080).
- Cookie là session -> sẽ hết hạn, phải chạy lại browser-auth.

Args MCP: --url https://<tenant> --client <nnn> --cookie-file C:\sap-mcp\<file>.txt --mode expert --enable-transports --allow-transportable-edits

Dấu hiệu cookie hết hạn khi query:
- XML syntax error on line 1: invalid character entity & (trả trang HTML login), hoặc
- fetching CSRF token: no CSRF token in response (HTTP 200).
=> Refresh cookie rồi restart server MCP đó (kill process vsp.exe khớp --url <tenant> -> gọi 1 tool để app
respawn). Đổi ARGS thì phải restart cả app (0.3).

Ví dụ đã cấu hình: Casla_Dev (my426517, client 080), Casla_Cus (my426501, client 100).

## 2B. vsp Public Cloud — TỰ LOGIN SAML, KHÔNG CẦN BROWSER (cách mặc định)

vsp có sẵn 3 cờ này (không hiện ở phần đầu `--help`, phải `vsp --help | findstr saml`):

    --saml-auth              Authenticate via programmatic SAML SSO (no browser, no MFA)
    --saml-user string       SAML/IAS username (email)
    --saml-password string   SAML/IAS secret

vsp tự login mỗi lần MCP server khởi động và **tự re-auth khi gặp 401** ⇒ không bao giờ phải chạy
browser-auth, hết hẳn lỗi "cookie hết hạn". Điều kiện: IdP **không bật MFA**.

### Kiến trúc 3 lớp (đã chạy thật: Casla_Dev/Cus/Test, KTQ_Dev/Cus, HTIT_DEV)

    manifest .dxt  ──►  C:\sap-mcp\vsp-launch.cmd <System>  ──►  vsp.exe --saml-auth ...
    (không secret)      (map System → URL/client/cookie)          (credential đọc từ .env)

1. **`C:\sap-mcp\.env`** — CHỈ chứa credential, mỗi khách 1 cặp biến (nhiều tenant cùng khách dùng chung):

       # --- Casla (my426517 dev / my426501 cus) ---
       CASLA_SAML_USER=<email>
       CASLA_SAML_PASSWORD=<...>
       # --- HTIT DEV (my428934) ---
       HTIT_SAML_USER=<email>
       HTIT_SAML_PASSWORD=<...>

   Đổi mật khẩu ⇒ sửa DUY NHẤT file này rồi restart Claude Desktop. KHÔNG commit, KHÔNG nhét vào .dxt.

2. **`C:\sap-mcp\vsp-launch.cmd <System>`** — template đầy đủ ở `assets/vsp/vsp-launch.cmd`. Lõi:

       for /f "usebackq eol=# tokens=1,* delims==" %%A in ("%ENVFILE%") do set "%%A=%%B"
       if /i "%SYS%"=="HTIT_DEV" goto :htit_dev
       ...
       "%VSP%" --url "%URL%" --client "%CLIENT%" --language EN ^
               --saml-auth --saml-user "%SAMLUSER%" --saml-password "%SAMLPASS%" ^
               --cookie-save "%COOKIE%" --mode expert ^
               --enable-transports --allow-transportable-edits

   Binary dùng: `C:\sap-mcp\vsp-dxt\vsp.exe`. `--cookie-save` VẪN chạy cùng `--saml-auth` → cookie sinh ra
   dùng cho CLI mode (mục 5) và để dò client/SID.

3. **manifest .dxt** — không có 1 ký tự credential nào:

       "server": { "type": "binary", "entry_point": "vsp.exe",
         "mcp_config": { "command": "cmd.exe",
                         "args": ["/c","C:\\sap-mcp\\vsp-launch.cmd","HTIT_DEV"] } }

   Vẫn khai `entry_point: vsp.exe` và bundle vsp.exe trong .dxt (~12MB) như pattern cũ.

### Thêm 1 tenant mới — chạy 1 script
`assets/vsp/setup-new-tenant.ps1`: sửa 7 biến đầu file (Sys / Url / Client / User / Prefix / Cookie /
DxtName) rồi

    powershell -ExecutionPolicy Bypass -File setup-new-tenant.ps1

Script làm 5 bước: hỏi secret ẩn tại chỗ → append `.env` (backup trước) → patch launcher (thêm nhãn +
dòng dispatch) → test SAML lấy cookie **và tự sửa client nếu đoán sai** → đóng gói `.dxt` + thêm profile
`~\.vsp.json` + verify `search "Z*"`. AI chỉ được launch script này (rule 10).

### Dò client & SID từ cookie
Tên cookie `SAP_SESSIONID_<SID>_<client>`, vd `SAP_SESSIONID_BDQ_080` ⇒ SID `BDQ`, client `080`.
Quy ước tenant Public Cloud: **dev tenant = 080**, **customizing tenant = 100** (đúng cho Casla, KTQ, HTIT).

### Bẫy đã gặp
- **Profile CLI `.vsp.json` KHÔNG đọc field `saml_*`** → `Error: auth not found for system 'X'. Set
  VSP_X_PASSWORD env var or use cookie_file/cookie_string`. Vì vậy profile vẫn khai `cookie_file` (cookie do
  launcher sinh ra); SAML chỉ truyền được qua **cờ dòng lệnh**, không qua profile.
- Patch launcher bằng regex: `-replace '(?m)^:run\r?\n'` ăn (kiểm 2026-08-28); nếu không ăn thì tách mảng
  dòng rồi `[Array]::IndexOf($lines,':run')`. Ghi file `.cmd` bằng **ASCII / UTF-8 no BOM** (BOM vỡ `@echo off`).
- `extensions-installations.json` có thể còn args cũ (`--cookie-file`) mà MCP vẫn chạy launcher mới ⇒ app đọc
  `manifest.json` trong folder extension. Nếu app dựng lại từ entry cũ → cài lại file `.dxt`.
- Chuyển hàng loạt extension đã cài sang launcher: `apply-saml-auth.ps1` (phải kill Claude Desktop trước vì
  `extensions-installations.json` bị LOCK khi app đang chạy) + `patch-manifests.ps1`.

### Tenant đã cấu hình (máy FIS)
| System | Tenant | Client | SID | Biến .env |
|---|---|---|---|---|
| Casla_Dev | my426517 | 080 | — | `CASLA_SAML_*` |
| Casla_Cus | my426501 | 100 | — | `CASLA_SAML_*` |
| Casla_Test | my426555 | 100 | AKO | `CASLA_TEST_SAML_*` |
| KTQ_Dev | my438051 | 080 | — | `KTQ_SAML_*` |
| KTQ_Cus | my438039 | 100 | — | `KTQ_SAML_*` |
| HTIT_DEV | my428934 | 080 | BDQ | `HTIT_SAML_*` |

IdP: Casla `anfsv0pr7.accounts.cloud.sap`, KTQ `a69m2oxmr.accounts.cloud.sap`, HTIT (Haiphong Port)
`aweufbfoif.accounts.cloud.sap` — đều không MFA.

## 2C. Rà soát MCP nào còn phải mở browser → chuyển sang SAML

Chạy đoạn này (PowerShell) để liệt kê MCP còn dùng cookie/browser. In ra **chỉ display_name + cờ**, KHÔNG in
args thô (args của hệ on-prem có credential — rule 10):

    $roots = @("$env:APPDATA\Claude\Claude Extensions",
               "$env:LOCALAPPDATA\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Roaming\Claude\Claude Extensions")
    foreach ($r in $roots) {
      if (-not (Test-Path $r)) { continue }
      Get-ChildItem $r -Directory | ForEach-Object {
        $mf = Join-Path $_.FullName 'manifest.json'
        if (-not (Test-Path $mf)) { return }
        $j = Get-Content $mf -Raw | ConvertFrom-Json
        $a = ($j.server.mcp_config.args -join ' ')
        $how = if ($a -match 'vsp-launch\.cmd') { 'SAML (OK)' }
               elseif ($a -match '--browser-auth') { 'BROWSER-AUTH -> can chuyen' }
               elseif ($a -match '--cookie-file')  { 'COOKIE FILE -> can chuyen' }
               elseif ($a -match '--user|SAP_USERNAME') { 'basic auth (on-prem, OK)' }
               else { 'khac' }
        '{0,-34} {1}' -f $j.display_name, $how
      }
    }

Đọc kết quả:
- `SAML (OK)` — đã tự login, không cần làm gì.
- `COOKIE FILE` / `BROWSER-AUTH` — **Public Cloud còn nợ**: sẽ có ngày báo `no CSRF token in response (HTTP 200)`
  hoặc `invalid character entity &` rồi phải mở browser. → NHẮC user + đề xuất chuyển ngay.
- `basic auth (on-prem, OK)` — hệ private cloud/on-prem, KHÔNG áp dụng SAML (mục 3), để nguyên.

### Chuyển 1 MCP Public Cloud từ cookie/browser sang SAML (4 bước)
1. Thêm cặp biến `<PREFIX>_SAML_USER` / `<PREFIX>_SAML_...` vào `C:\sap-mcp\.env` — để script tự hỏi
   (`Read-Host -AsSecureString`), AI không gõ (rule 10).
2. Thêm nhánh `:<label>` vào `C:\sap-mcp\vsp-launch.cmd` (URL + client + cookie file + 2 biến trên).
3. Trỏ manifest sang launcher — sửa **CẢ HAI** chỗ: `manifest.json` trong folder extension **và**
   `extensions-installations.json` (key theo id), UTF-8 no BOM:
   `command: "cmd.exe"`, `args: ["/c","C:\\sap-mcp\\vsp-launch.cmd","<System>"]`.
   Làm hàng loạt bằng `apply-saml-auth.ps1` — **phải kill Claude Desktop trước** vì
   `extensions-installations.json` bị LOCK khi app đang chạy.
4. RESTART HẲN Claude Desktop, rồi verify bằng `SearchObject` (đừng dùng GetSystemInfo — mục 6).

Cách nhanh hơn khi tenant chưa có extension: chạy `assets/vsp/setup-new-tenant.ps1` (làm cả 4 bước + đóng gói
`.dxt` mới), rồi cài đè extension cũ.

## 3. vsp — Private Cloud / on-prem (basic auth)

On-prem dùng basic auth (user/password), thường sau VPN, IP nội bộ.

Args MCP: --url https://<ip>:44300 --client <nnn> --user <U> --password <P> --language EN --insecure --mode expert --enable-transports --allow-transportable-edits

QUIRK đã kiểm chứng (hệ VJC / DS4, 172.29.3.126):
- DÙNG HTTPS cổng 44300, KHÔNG dùng HTTP 8000: auth OK nhưng SAP ICM redirect sang FQDN
  (vd vhvjtds4ci.sap.vietjetair.com) mà máy không phân giải DNS được -> lỗi getaddrinfow. HTTPS 44300 qua IP
  thì KHÔNG bị redirect.
- Cert self-signed -> cần --insecure (MCP server) hoặc "insecure": true (profile CLI).
- Cần VPN (FortiClient); mất VPN thì không nối.

Verify nhanh (CLI, mục 5): vsp -s <sys> search "Z*" -> phải trả Z001/ZABAP*/...

## 4. Server Python FastMCP (vd sap-gui — điều khiển SAP GUI Scripting)

Khi MCP là server Python (không phải binary): bundle file .py vào extension, chạy bằng venv có sẵn deps.

    "server": {
      "type": "python",
      "entry_point": "server.py",
      "mcp_config": {
        "command": "C:\\sap-mcp\\venv\\Scripts\\python.exe",
        "args": ["${__dirname}/server.py"]
      }
    }

- Bundle server.py + module phụ (vd sap_gui.py) vào folder extension (Python thêm thư mục script vào
  sys.path nên import <module> cạnh file chạy được).
- command trỏ venv python tuyệt đối (venv chứa mcp, pywin32...). Test import trước:
  venv\Scripts\python.exe -c "import <module>; from mcp.server.fastmcp import FastMCP; print('OK')".
- Runtime sap-gui: cần SAP GUI cài sẵn + bật Scripting (client Options + server sapgui/user_scripting=TRUE)
  + đang mở 1 session SAP GUI.

## 4B. Server Node/TypeScript (vd mcp-abap-adt — mario-andreschak)

Một số MCP SAP là **server Node/TypeScript** cần build từ source, KHÔNG phải binary Go (vsp) hay Python.
Ví dụ kinh điển: `mcp-abap-adt` của **mario-andreschak** (https://github.com/mario-andreschak/mcp-abap-adt) —
bridge ADT cho ABAP, CHỈ hỗ trợ **basic auth** (SAP_URL / SAP_USERNAME / SAP_PASSWORD / SAP_CLIENT) nên hợp
hệ **on-prem / private cloud** (KHÔNG hợp Public Cloud tenant vốn dùng SSO cookie).

### Quy trình (đã kiểm chứng trên máy này — hệ VJC on-prem 172.29.3.126:44300 client 100)
1. Kiểm prereq (PowerShell qua Windows-MCP): `node -v; npm -v; git --version` (máy này có node v24 / npm 11 / git 2.54).
2. Clone + build vào `C:\sap-mcp\<repo>`:
   ```
   cd C:\sap-mcp; git clone <repo-url>; cd <repo>; npm install; npm run build
   ```
   → sinh `dist/index.js` (xem `package.json` field `main`).
3. Cấu hình credential. `mcp-abap-adt` đọc `.env` qua dotenv từ `dist/../.env` (tức root project).
   Ghi `.env` UTF-8 **no BOM** (nếu password có `#` phải bọc nháy; `@` thì không cần):
   ```
   SAP_URL=https://172.29.3.126:44300
   SAP_USERNAME=<user>
   SAP_PASSWORD=<pass>
   SAP_CLIENT=100
   ```
   Cert self-signed: repo này đã set sẵn `rejectUnauthorized:false` trong `utils.ts` → KHÔNG cần cờ TLS.
   (Repo khác nếu lỗi cert self-signed thì thêm env `NODE_TLS_REJECT_UNAUTHORIZED=0`.)
4. **Manifest .dxt kiểu node** — mirror pattern của các MCP node cài sẵn (vd SAP Fiori MCP): `type:"node"`,
   `command:"node"`, args trỏ tuyệt đối tới `dist/index.js`. Thin .dxt (chỉ đóng gói `manifest.json`),
   giữ nguyên project ở `C:\sap-mcp\<repo>` (KHÔNG bundle `node_modules` ~66MB vào .dxt). Truyền credential
   qua `mcp_config.env` cho chắc (song song với `.env`):
   ```
   {
     "manifest_version": "0.3",
     "name": "mcp-abap-adt-vjc",
     "display_name": "MARIO_VJC_DEV_100",
     "version": "1.2.0",
     "description": "mario mcp-abap-adt - ADT bridge VJC on-prem.",
     "author": { "name": "mario-andreschak" },
     "server": {
       "type": "node",
       "entry_point": "C:\\sap-mcp\\mcp-abap-adt\\dist\\index.js",
       "mcp_config": {
         "command": "node",
         "args": ["C:\\sap-mcp\\mcp-abap-adt\\dist\\index.js"],
         "env": { "SAP_URL": "https://172.29.3.126:44300", "SAP_USERNAME": "<user>", "SAP_PASSWORD": "<pass>", "SAP_CLIENT": "100" }
       }
     },
     "compatibility": { "platforms": ["win32"] },
     "license": "MIT"
   }
   ```
   Đóng gói: `Compress-Archive manifest.json -> .zip` rồi rename `.dxt`, copy ra `D:\AI\AI_PROJECT` để present_files
   (thin .dxt ~0.6KB). Lưu ý thin .dxt: nếu xoá/di chuyển `C:\sap-mcp\<repo>` là extension chết.
5. **Verify KHÔNG cần VPN** bằng MCP handshake stdio (initialize + tools/list) — server phải trả danh sách tool:
   ```
   $init='{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"t","version":"1"}}}'
   $list='{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}'
   "$init`n$list`n" | node dist/index.js
   ```
   `mcp-abap-adt` trả: GetProgram, GetClass, GetFunctionGroup, GetFunction, GetStructure, GetTable,
   GetTableContents, GetPackage, GetTypeInfo, GetInclude, SearchObject, GetInterface, GetTransaction.
6. Cài qua **Settings > Extensions > Advanced > Install extension** + restart HẲN (như mọi .dxt).
   Namespace tool = `mcp__MARIO_VJC_DEV_100__*`.

### Lưu ý runtime
- Cần **VPN** khi thật sự gọi tool (kết nối tới IP nội bộ on-prem).
- `GetTableContents` cần service custom `/z_mcp_abap_adt/z_tablecontent` trên hệ SAP; các tool còn lại chỉ
  cần `/sap/bc/adt` (bật trong SICF).
- Có thể chạy song song với vsp cùng trỏ 1 hệ (vd `Vibing Steampunk VJC Dev`) — bổ sung bộ tool ADT của mario.


## 5. Profile CLI .vsp.json (test nhanh, đa hệ thống)

Ở C:\Users\<user>\.vsp.json. UTF-8 KHÔNG BOM. CLI subcommand chỉ nhận -s <system> (KHÔNG nhận
--url/--cookie-file; global flag như --insecure KHÔNG dùng được ở subcommand — đặt field "insecure": true
trong profile). Password inline hoặc env VSP_<SYSTEM>_PASSWORD.

    {
      "systems": {
        "Casla_Dev":     { "url": "https://my426517.s4hana.cloud.sap", "client": "080", "language": "EN", "cookie_file": "C:\\sap-mcp\\vsp-cookies.txt" },
        "Casla_Cus":     { "url": "https://my426501.s4hana.cloud.sap", "client": "100", "language": "EN", "cookie_file": "C:\\sap-mcp\\vsp-cookies-cus.txt" },
        "VJC_CLOUD_DEV": { "url": "https://172.29.3.126:44300", "client": "100", "language": "EN", "user": "FPT-DUBV", "insecure": true }
      },
      "default": "Casla_Dev"
    }

Dùng: vsp -s <system> search "ZCL*" / source CLAS <name> / query <TABLE> --top N / config show -s <system>.

## 6. Verify sau khi cài & quirk

- Test kết nối bằng SearchObject (query ZCL*), KHÔNG dùng GetSystemInfo — trên nhiều tenant nó chạy freestyle
  data-preview cần authorization S_ABPLNGVS và luôn báo lỗi dù auth OK.
- Data preview (RunQuery/vsp query): view released query được nhưng có thể trả 0 dòng (DCL/quyền); bảng DDIC
  chuẩn (MARA, TADIR...) bị chặn (S_ABPLNGVS) — bình thường ở Public Cloud.
- search bị cap ~19k kết quả/lần và cắt phần sau (dấu "_" sắp sau Z) -> muốn liệt kê nhóm lớn phải quét tiền
  tố mịn (I_PR*...). --type DDLS lọc CDS.

## 7. Checklist tạo 1 MCP SAP mới
- Xác định loại: vsp Public Cloud (**SAML tự login — mục 2B, mặc định**; cookie browser-auth chỉ dự phòng)
  / vsp on-prem (basic auth) / Python server / Node server.
- Public Cloud: KHÔNG viết manifest chứa credential — dùng `.env` + `vsp-launch.cmd` + script
  `assets/vsp/setup-new-tenant.ps1`.
- Chuẩn bị binary/script + auth (cookie file hoặc user/pass); test bằng CLI profile .vsp.json trước.
- Viết manifest: display_name sạch (không "/"), args đúng (thêm --insecure nếu on-prem; LUÔN kèm
  --enable-transports --allow-transportable-edits — xem rule 8).
- Đóng gói .dxt, copy ra D:\AI\AI_PROJECT, present_files.
- Hướng dẫn user cài qua Settings > Extensions > Advanced + restart app.
- Verify bằng SearchObject. Ghi memory (không lưu secret).
- **Rà soát mục 2C**: MCP nào còn browser-auth/cookie-file thì NHẮC user + đề xuất chuyển sang SAML (rule 11).

## 8. File bundle kèm skill (assets/)
- assets/vsp/vsp-launch.cmd — launcher SAML đa hệ (mục 2B), copy vào `C:\sap-mcp\` rồi thêm nhánh mới.
- assets/vsp/setup-new-tenant.ps1 — script thêm 1 tenant Public Cloud end-to-end (.env → launcher →
  test SAML → .dxt → profile → verify), secret nhập tại chỗ trên máy user.
- assets/sap-gui/server.py, assets/sap-gui/sap_gui.py — mã nguồn MCP sap-gui (FastMCP điều khiển SAP GUI
  Scripting). Để tái tạo: copy 2 file này + đóng gói .dxt theo mục 4 (command trỏ venv python có sẵn mcp+pywin32).
- vsp.exe KHÔNG kèm (~16MB) — tải từ GitHub oisee/vibing-steampunk hoặc build bằng Go, đặt ở C:\sap-mcp\.

## 9. Cài Python + venv cho server Python (nếu máy chưa có)

MCP kiểu Python (vd sap-gui) cần Python trên Windows + venv có deps `mcp` và `pywin32` (win32com để gọi
SAP GUI Scripting qua COM).

Kiểm tra đã có Python chưa (PowerShell):

    python --version ; where.exe python
    # hoặc Windows Python launcher:
    py --version

Nếu CHƯA có, cài (chọn 1):

    # Cách 1 - winget (Win10/11):
    winget install -e --id Python.Python.3.12
    # Cách 2 - tải installer python.org, khi cài TICK "Add python.exe to PATH".

Tạo venv ở C:\sap-mcp\venv và cài deps:

    python -m venv C:\sap-mcp\venv
    C:\sap-mcp\venv\Scripts\python.exe -m pip install --upgrade pip
    C:\sap-mcp\venv\Scripts\python.exe -m pip install mcp pywin32

Verify (phải in OK):

    C:\sap-mcp\venv\Scripts\python.exe -c "import win32com.client; from mcp.server.fastmcp import FastMCP; print('OK')"

Lưu ý:
- Manifest .dxt của server Python trỏ command = C:\sap-mcp\venv\Scripts\python.exe (tuyệt đối) nên venv phải
  ở đúng đường dẫn đó; nếu đặt chỗ khác thì sửa command trong manifest cho khớp.
- win32com (pywin32) chỉ chạy trên Windows; SAP GUI Scripting yêu cầu SAP GUI cài sẵn + bật Scripting
  (client Options + server sapgui/user_scripting=TRUE) + đang mở 1 session.
- Nếu winget bị chặn (máy công ty), tải installer offline python.org rồi cài thủ công.

## 10. Cài binary vsp (Vibing Steampunk) — https://github.com/oisee/vibing-steampunk

vsp là 1 binary Go độc lập (9 nền tảng, không cần dependency). Đặt tại C:\sap-mcp\vibing-steampunk\vsp.exe.

### Cách A — Tải bản release (khuyên dùng, nhanh)
1. Vào https://github.com/oisee/vibing-steampunk/releases → tải asset Windows (vd `vsp-windows-amd64.exe`).
2. Đổi tên thành `vsp.exe`, đặt vào `C:\sap-mcp\vibing-steampunk\`.

PowerShell (nếu trình duyệt chặn tải .exe):

    New-Item -ItemType Directory -Force C:\sap-mcp\vibing-steampunk | Out-Null
    Invoke-WebRequest -Uri "https://github.com/oisee/vibing-steampunk/releases/latest/download/vsp-windows-amd64.exe" -OutFile "C:\sap-mcp\vibing-steampunk\vsp.exe"
    # (nếu tên asset khác, mở trang releases xem tên đúng của bản windows-amd64)

(Tuỳ chọn) thêm folder vào PATH user: KEY_CURRENT_USER\Environment\Path → thêm C:\sap-mcp\vibing-steampunk.

### Cách B — Build từ source (khi cần bản mới nhất / không tải được release)
Cần Go:

    winget install -e --id GoLang.Go
    git clone https://github.com/oisee/vibing-steampunk.git C:\sap-mcp\vibing-steampunk
    cd C:\sap-mcp\vibing-steampunk

QUIRK (đã gặp): module Go tải qua proxy.golang.org hay bị reset ở mạng này → set GOPROXY thay thế trước khi build:

    $env:GOPROXY="https://goproxy.io,direct"
    go build -o vsp.exe .
    # hoặc nếu có make: make build

### Verify
    C:\sap-mcp\vibing-steampunk\vsp.exe --version
    C:\sap-mcp\vibing-steampunk\vsp.exe --help
    # tạo template config (tuỳ chọn): vsp config init  -> .env.example / .vsp.json.example / .mcp.json.example

Sau khi có vsp.exe: dùng làm binary trong manifest .dxt (mục 1), cấu hình hệ thống (mục 2 Public Cloud /
mục 3 on-prem), hoặc test nhanh bằng CLI profile .vsp.json (mục 5).

## 11. Lỗi thường gặp & cách xử lý (troubleshooting)

### 11.1 Install .dxt báo `Invalid manifest: author: Required`
Manifest thiếu field `author`. Manifest 0.3 BẮT BUỘC có `author`. Thêm:

    "author": { "name": "FIS" }

Lưu ý: double-click file .dxt để "preview" cũng validate manifest → cùng lỗi. Cách cài đúng luôn là
Settings > Extensions > Advanced > Install extension (không phải double-click).

### 11.2 Không tìm thấy Claude Extensions/config/logs (bản Windows Store app)
Bản Claude Desktop cài từ Microsoft Store KHÔNG dùng `%APPDATA%\Claude`. Đường dẫn data THẬT:

    C:\Users\<user>\AppData\Local\Packages\Claude_pzs8sxrjxfjjc\LocalCache\Roaming\Claude\

→ Thư mục `Claude Extensions\`, `extensions-installations.json`, `logs\`, `claude_desktop_config.json`
đều nằm dưới đây. (Bản cài .exe thường thì ở `%APPDATA%\Claude`.) Kiểm tra cả hai khi thao tác extension.

### 11.3 Windows-MCP không kết nối — uv lỗi tải Python 3.13 (symlink)
Extension `ant.dir.cursortouch.windows-mcp` yêu cầu Python >=3.13; uv cố tải 3.13 và lỗi:

    error: Missing expected target directory for Python minor version link at
    ...\uv\python\cpython-3.13.14-windows-x86_64-none

Fix: ghi đè `.python-version` trong folder extension thành phiên bản Python ĐÃ CÀI trên máy (vd 3.14):

    echo 3.14> "<Claude data>\Claude Extensions\ant.dir.cursortouch.windows-mcp\.python-version"

Rồi restart Claude Desktop → Windows-MCP kết nối. (Windows-MCP rất hữu ích để tự động hoá các bước cài MCP.)

### 11.4 Cookie SSO hết hạn (Public Cloud)
**Fix gốc: chuyển sang SAML tự login (mục 2B) — hết hẳn class lỗi này.** Nếu vẫn đang dùng cookie:
Query lỗi `no CSRF token in response (HTTP 200)` hoặc `invalid character entity &` (server trả trang HTML
login) = cookie hết hạn. Chạy lại `--browser-auth ... --cookie-save`, rồi restart Claude Desktop (hoặc
restart server MCP đó). Verify bằng `SearchObject`, KHÔNG dùng `GetSystemInfo` (cần S_ABPLNGVS, hay lỗi dù auth OK).

### 11.6 vsp on-prem: transport bị chặn / KHÔNG tạo được package · domain · data element (DS4/VJC)
Mặc định vsp chặn transport. Bật bằng args (rule 8): `--enable-transports` + `--allow-transportable-edits`.
Sau khi bật, tạo được TR (CreateTransport) và table (CreateTable) OK, NHƯNG trên hệ on-prem DS4 vẫn còn 2 tường:
- `CreatePackage` / `CreateObject DEVC` qua ADT → lỗi cố hữu `CTS_WBO_API 047: "Request <TR> is not a local
  request"` (HTTP 409, ExceptionResourceLockConflict). vsp gửi payload khiến package bị coi là local nhưng
  đưa transport transportable → xung đột. Đổi TR mới vẫn y hệt. => KHÔNG tạo được package qua vsp ADT.
- Tạo bằng ABAP qua `ExecuteABAP` (`CL_PACKAGE_FACTORY`, `DDIF_DOMA_PUT`, `DDIF_DTEL_PUT`...) → BẤT KHẢ THI:
  ExecuteABAP chạy code trong wrapper ABAP Unit, mà ABAP Unit CHẶN `COMMIT WORK` (gọi COMMIT là test bị
  huỷ, không có output, thay đổi bị rollback). Mọi tạo/activate DDIC đều cần COMMIT/update task → không persist.
Dấu hiệu ExecuteABAP bị chặn COMMIT: chạy "Success: true" nhưng **no output captured** và không có Raw Alert
(assertion sau COMMIT không kích hoạt). Kiểm chứng: chạy 1 đoạn có `COMMIT WORK` rồi set lv_result — sẽ mất output.
=> Kết luận: package · domain · data element trên on-prem PHẢI tạo qua **SAP GUI** (SE21 package; SE11
domain/DE/table) — xem skill fis-sap-private-cloud-deploy. vsp chỉ dùng để tạo table (khi package đã có) và
đọc/sửa source code, chạy query (RunQuery/GetTableContents, không cần COMMIT).

### 11.5 Kích thước tham khảo
vsp.exe (windows-amd64) ~16MB; file `.dxt` đóng gói (kèm vsp.exe) ~5.9MB (nén). Đừng bundle vsp.exe vào skill.
